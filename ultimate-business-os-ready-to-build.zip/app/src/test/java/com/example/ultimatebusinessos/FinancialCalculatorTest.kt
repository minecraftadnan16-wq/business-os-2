package com.example.ultimatebusinessos

import com.example.ultimatebusinessos.domain.calculation.FinancialCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialCalculatorTest {

    @Test
    fun testLineItemCalculation_precision() {
        // Quantity 3, price $25.50, cost $12.00, discount 10%, tax 5%
        val line = FinancialCalculator.calculateLineItem(
            quantity = 3.0,
            unitPrice = 25.50,
            costPrice = 12.00,
            discountPercent = 10.0,
            taxRatePercent = 5.0
        )

        // Raw subtotal: 3 * 25.50 = 76.50
        assertEquals(76.50, line.rawSubtotal, 0.001)
        // Discount: 76.50 * 0.10 = 7.65
        assertEquals(7.65, line.discountAmount, 0.001)
        // Taxable: 76.50 - 7.65 = 68.85
        assertEquals(68.85, line.taxableAmount, 0.001)
        // Tax: 68.85 * 0.05 = 3.4425 -> 3.44
        assertEquals(3.44, line.taxAmount, 0.001)
        // Line total: 68.85 + 3.44 = 72.29
        assertEquals(72.29, line.lineTotal, 0.001)
        // Cost total: 3 * 12.00 = 36.00
        assertEquals(36.00, line.costTotal, 0.001)
        // Gross profit: 68.85 - 36.00 = 32.85
        assertEquals(32.85, line.grossProfit, 0.001)
    }

    @Test
    fun testInvoiceCalculation_aggregation() {
        val line1 = FinancialCalculator.calculateLineItem(
            quantity = 2.0,
            unitPrice = 50.0,
            costPrice = 20.0,
            discountPercent = 0.0,
            taxRatePercent = 10.0
        )
        val line2 = FinancialCalculator.calculateLineItem(
            quantity = 1.0,
            unitPrice = 100.0,
            costPrice = 60.0,
            discountPercent = 20.0,
            taxRatePercent = 10.0
        )

        val invoice = FinancialCalculator.calculateInvoice(
            lines = listOf(line1, line2),
            amountPaid = 150.0
        )

        // line 1: subtotal 100, tax 10, total 110
        // line 2: subtotal 100, disc 20, taxable 80, tax 8, total 88
        // invoice subtotal: 200
        assertEquals(200.0, invoice.subtotal, 0.001)
        assertEquals(20.0, invoice.totalDiscount, 0.001)
        assertEquals(18.0, invoice.totalTax, 0.001)
        assertEquals(198.0, invoice.grandTotal, 0.001)
        // Paid 150, due 48
        assertEquals(48.0, invoice.balanceDue, 0.001)
    }

    @Test
    fun testCryptographicTamperSeal_deterministicAndUnique() {
        val hash1 = FinancialCalculator.generateInvoiceTamperSeal(
            previousReceiptHash = "0000000000000000",
            businessId = 1L,
            invoiceNumber = "INV-001",
            timestampEpoch = 1700000000000L,
            grandTotal = 198.0
        )

        val hash2 = FinancialCalculator.generateInvoiceTamperSeal(
            previousReceiptHash = "0000000000000000",
            businessId = 1L,
            invoiceNumber = "INV-001",
            timestampEpoch = 1700000000000L,
            grandTotal = 198.0
        )

        val hash3 = FinancialCalculator.generateInvoiceTamperSeal(
            previousReceiptHash = hash1,
            businessId = 1L,
            invoiceNumber = "INV-002",
            timestampEpoch = 1700000005000L,
            grandTotal = 250.0
        )

        assertEquals(hash1, hash2)
        assertNotEquals(hash1, hash3)
        assertTrue(hash1.length == 16)
    }
}
