package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Liquid Glass Core Brand Colors
val LiquidCyan = Color(0xFF00E5FF)
val LiquidCyanGlow = Color(0xFF38BDF8)
val LiquidEmerald = Color(0xFF10B981)
val LiquidViolet = Color(0xFF8B5CF6)
val LiquidAmber = Color(0xFFF59E0B)
val LiquidRose = Color(0xFFF43F5E)

// Liquid Glass Void & Backgrounds
val GlassVoidDark = Color(0xFF050814)
val GlassSurfaceDark = Color(0xFF0B132B)
val GlassCanvasDark = Color(0xFF0F172A)

// Glass Translucency Tokens
val GlassWhiteHigh = Color(0x33FFFFFF)
val GlassWhiteMedium = Color(0x1FFFFFFF)
val GlassWhiteLow = Color(0x0DFFFFFF)
val GlassBorderGradientStart = Color(0x55FFFFFF)
val GlassBorderGradientEnd = Color(0x10FFFFFF)
val GlassBorderCyanStart = Color(0x8038BDF8)
val GlassBorderCyanEnd = Color(0x1538BDF8)

// Light Glass Tokens
val GlassIceBackground = Color(0xFFF1F5F9)
val GlassIceSurface = Color(0xFFFFFFFF)
val GlassIceCard = Color(0xCCFFFFFF)

// Material 3 Dark Palette
val GlassPrimaryDark = Color(0xFF38BDF8)
val GlassOnPrimaryDark = Color(0xFF032238)
val GlassPrimaryContainerDark = Color(0xFF0C4A6E)
val GlassOnPrimaryContainerDark = Color(0xFFBAE6FD)

val GlassSecondaryDark = Color(0xFF2DD4BF)
val GlassOnSecondaryDark = Color(0xFF003730)
val GlassSecondaryContainerDark = Color(0xFF134E4A)
val GlassOnSecondaryContainerDark = Color(0xFF99F6E4)

val GlassTertiaryDark = Color(0xFFA78BFA)
val GlassOnTertiaryDark = Color(0xFF2E1065)
val GlassTertiaryContainerDark = Color(0xFF4C1D95)
val GlassOnTertiaryContainerDark = Color(0xFFDDD6FE)

val GlassBackgroundDark = Color(0xFF060913)
val GlassSurfaceDarkM3 = Color(0xFF0B1120)
val GlassOnBackgroundDark = Color(0xFFF8FAFC)
val GlassOnSurfaceDark = Color(0xFFF1F5F9)
val GlassSurfaceVariantDark = Color(0xFF1E293B)
val GlassOnSurfaceVariantDark = Color(0xFF94A3B8)
val GlassOutlineDark = Color(0xFF475569)

// Material 3 Light Palette
val GlassPrimaryLight = Color(0xFF0284C7)
val GlassOnPrimaryLight = Color(0xFFFFFFFF)
val GlassPrimaryContainerLight = Color(0xFFE0F2FE)
val GlassOnPrimaryContainerLight = Color(0xFF0369A1)

val GlassSecondaryLight = Color(0xFF0D9488)
val GlassOnSecondaryLight = Color(0xFFFFFFFF)
val GlassSecondaryContainerLight = Color(0xFFCCFBF1)
val GlassOnSecondaryContainerLight = Color(0xFF115E59)

val GlassTertiaryLight = Color(0xFF7C3AED)
val GlassOnTertiaryLight = Color(0xFFFFFFFF)
val GlassTertiaryContainerLight = Color(0xFFEDE9FE)
val GlassOnTertiaryContainerLight = Color(0xFF5B21B6)

val GlassBackgroundLight = Color(0xFFF8FAFC)
val GlassSurfaceLightM3 = Color(0xFFFFFFFF)
val GlassOnBackgroundLight = Color(0xFF0F172A)
val GlassOnSurfaceLight = Color(0xFF1E293B)
val GlassSurfaceVariantLight = Color(0xFFE2E8F0)
val GlassOnSurfaceVariantLight = Color(0xFF64748B)
val GlassOutlineLight = Color(0xFFCBD5E1)
