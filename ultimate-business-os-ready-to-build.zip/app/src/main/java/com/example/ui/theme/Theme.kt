package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = GlassPrimaryDark,
    onPrimary = GlassOnPrimaryDark,
    primaryContainer = GlassPrimaryContainerDark,
    onPrimaryContainer = GlassOnPrimaryContainerDark,
    secondary = GlassSecondaryDark,
    onSecondary = GlassOnSecondaryDark,
    secondaryContainer = GlassSecondaryContainerDark,
    onSecondaryContainer = GlassOnSecondaryContainerDark,
    tertiary = GlassTertiaryDark,
    onTertiary = GlassOnTertiaryDark,
    tertiaryContainer = GlassTertiaryContainerDark,
    onTertiaryContainer = GlassOnTertiaryContainerDark,
    background = GlassBackgroundDark,
    onBackground = GlassOnBackgroundDark,
    surface = GlassSurfaceDarkM3,
    onSurface = GlassOnSurfaceDark,
    surfaceVariant = GlassSurfaceVariantDark,
    onSurfaceVariant = GlassOnSurfaceVariantDark,
    outline = GlassOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = GlassPrimaryLight,
    onPrimary = GlassOnPrimaryLight,
    primaryContainer = GlassPrimaryContainerLight,
    onPrimaryContainer = GlassOnPrimaryContainerLight,
    secondary = GlassSecondaryLight,
    onSecondary = GlassOnSecondaryLight,
    secondaryContainer = GlassSecondaryContainerLight,
    onSecondaryContainer = GlassOnSecondaryContainerLight,
    tertiary = GlassTertiaryLight,
    onTertiary = GlassOnTertiaryLight,
    tertiaryContainer = GlassTertiaryContainerLight,
    onTertiaryContainer = GlassOnTertiaryContainerLight,
    background = GlassBackgroundLight,
    onBackground = GlassOnBackgroundLight,
    surface = GlassSurfaceLightM3,
    onSurface = GlassOnSurfaceLight,
    surfaceVariant = GlassSurfaceVariantLight,
    onSurfaceVariant = GlassOnSurfaceVariantLight,
    outline = GlassOutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep default Liquid Glass branding
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
