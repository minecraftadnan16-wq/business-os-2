package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ultimatebusinessos.ui.theme.GlassFloatingDock
import com.example.ultimatebusinessos.ui.theme.liquidGlassBackground
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.example.ultimatebusinessos.ui.components.AppNavigationDrawer
import com.example.ultimatebusinessos.ui.screens.AiAssistantScreen
import com.example.ultimatebusinessos.ui.screens.ArchitectureViewerScreen
import com.example.ultimatebusinessos.ui.screens.AuditFinancialReportsScreen
import com.example.ultimatebusinessos.ui.screens.BusinessSwitcherScreen
import com.example.ultimatebusinessos.ui.screens.CashAndBankScreen
import com.example.ultimatebusinessos.ui.screens.ContactsLedgerScreen
import com.example.ultimatebusinessos.ui.screens.DocumentsScreen
import com.example.ultimatebusinessos.ui.screens.EmployeesScreen
import com.example.ultimatebusinessos.ui.screens.InventoryScreen
import com.example.ultimatebusinessos.ui.screens.PointOfSaleScreen
import com.example.ultimatebusinessos.ui.screens.ProfessionalModeDashboard
import com.example.ultimatebusinessos.ui.screens.PurchasesScreen
import com.example.ultimatebusinessos.ui.screens.SettingsScreen
import com.example.ultimatebusinessos.ui.screens.SimpleModeDashboard
import com.example.ultimatebusinessos.ui.screens.SmartReminderCenterScreen
import com.example.ultimatebusinessos.ui.viewmodel.AppOperatingMode
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen
import com.example.ultimatebusinessos.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                UltimateBusinessOsApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UltimateBusinessOsApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val operatingMode by viewModel.operatingMode.collectAsState()
    val activeBusiness by viewModel.activeBusiness.collectAsState()
    val allBusinesses by viewModel.allBusinesses.collectAsState()
    val products by viewModel.products.collectAsState()
    val lowStockProducts by viewModel.lowStockProducts.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val salesOrders by viewModel.salesOrders.collectAsState()
    val purchaseOrders by viewModel.purchaseOrders.collectAsState()
    val ledgerEntries by viewModel.ledgerEntries.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val employees by viewModel.employees.collectAsState()
    val isReducedMotion by viewModel.isReducedMotion.collectAsState()

    val revenue by viewModel.totalRevenue.collectAsState()
    val expenses by viewModel.totalExpenses.collectAsState()
    val inventoryValuation by viewModel.inventoryValuation.collectAsState()
    val receivables by viewModel.totalReceivables.collectAsState()
    val payables by viewModel.totalPayables.collectAsState()
    val cashBalance by viewModel.cashOnHandBalance.collectAsState()
    val bankBalance by viewModel.bankAccountBalance.collectAsState()

    val cart by viewModel.cart.collectAsState()
    val selectedCustomer by viewModel.selectedCustomer.collectAsState()
    val paymentMethod by viewModel.paymentMethod.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        viewModel.uiMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Predictive system back handling
    if (currentScreen != AppScreen.DASHBOARD) {
        BackHandler {
            viewModel.navigateTo(AppScreen.DASHBOARD)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppNavigationDrawer(
                currentScreen = currentScreen,
                operatingMode = operatingMode,
                activeBusiness = activeBusiness,
                onSelectScreen = { screen ->
                    viewModel.navigateTo(screen)
                    scope.launch { drawerState.close() }
                },
                onToggleMode = {
                    viewModel.toggleOperatingMode()
                }
            )
        }
    ) {
        val isDark = isSystemInDarkTheme()

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .liquidGlassBackground(isDark = isDark, isReducedMotion = isReducedMotion)
                .safeDrawingPadding(),
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = currentScreen.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFFF1F5F9) else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = activeBusiness?.businessName ?: "Ultimate Business OS",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isDark) Color(0xFF94A3B8) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("btn_open_drawer")
                        ) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = "Navigation Menu",
                                tint = if (isDark) Color(0xFFE2E8F0) else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    actions = {
                        // Quick Operating Mode Switcher Chip in Top Bar with frosted glass surface
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (operatingMode == AppOperatingMode.SIMPLE) {
                                if (isDark) Color(0x3310B981) else MaterialTheme.colorScheme.primaryContainer
                            } else {
                                if (isDark) Color(0x3300E5FF) else Color(0xFF0F172A)
                            },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clickable { viewModel.toggleOperatingMode() }
                                .testTag("btn_toggle_mode_topbar")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (operatingMode == AppOperatingMode.SIMPLE) "Simple" else "Pro ERP",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (operatingMode == AppOperatingMode.SIMPLE) {
                                        if (isDark) Color(0xFF34D399) else MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        Color(0xFF38BDF8)
                                    }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = "Switch Mode",
                                    tint = if (operatingMode == AppOperatingMode.SIMPLE) {
                                        if (isDark) Color(0xFF34D399) else MaterialTheme.colorScheme.primary
                                    } else {
                                        Color(0xFF38BDF8)
                                    },
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = if (isDark) Color(0x330B1226) else Color(0x88FFFFFF)
                    ),
                    modifier = Modifier.drawBehind {
                        drawLine(
                            color = if (isDark) Color(0x22FFFFFF) else Color(0x22000000),
                            start = Offset(0f, size.height),
                            end = Offset(size.width, size.height),
                            strokeWidth = 1f
                        )
                    }
                )
            },
            bottomBar = {
                LiquidGlassBottomDock(
                    currentScreen = currentScreen,
                    operatingMode = operatingMode,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        ) { innerPadding ->
            val screenModifier = Modifier.padding(innerPadding)

            when (currentScreen) {
                AppScreen.DASHBOARD -> {
                    if (operatingMode == AppOperatingMode.SIMPLE) {
                        SimpleModeDashboard(
                            business = activeBusiness,
                            revenue = revenue,
                            expenses = expenses,
                            cashBalance = cashBalance,
                            receivables = receivables,
                            payables = payables,
                            lowStockCount = lowStockProducts.size,
                            contacts = contacts,
                            onNavigate = { viewModel.navigateTo(it) },
                            onReceiveMoney = { cust, amt, dest, notes -> viewModel.receiveCustomerPayment(cust, amt, dest, notes) },
                            onPayMoney = { supp, amt, src, notes -> viewModel.paySupplierBill(supp, amt, src, notes) },
                            onAddExpense = { title, amt, cat -> viewModel.recordExpense(title, amt, cat) },
                            onSwitchMode = { viewModel.toggleOperatingMode() },
                            modifier = screenModifier
                        )
                    } else {
                        ProfessionalModeDashboard(
                            business = activeBusiness,
                            revenue = revenue,
                            expenses = expenses,
                            inventoryValuation = inventoryValuation,
                            cashBalance = cashBalance,
                            bankBalance = bankBalance,
                            receivables = receivables,
                            payables = payables,
                            ledgerEntries = ledgerEntries,
                            products = products,
                            onNavigate = { viewModel.navigateTo(it) },
                            onRecordJournalEntry = { dr, cr, amt, desc -> viewModel.recordJournalEntry(dr, cr, amt, desc) },
                            onToggleReconciliation = { id, rec -> viewModel.toggleLedgerReconciliation(id, rec) },
                            onSwitchMode = { viewModel.toggleOperatingMode() },
                            modifier = screenModifier
                        )
                    }
                }

                AppScreen.MY_BUSINESSES -> BusinessSwitcherScreen(
                    activeBusiness = activeBusiness,
                    allBusinesses = allBusinesses,
                    onSelectBusiness = { viewModel.switchBusiness(it) },
                    onCreateBusiness = { name, tagline, cat, symbol, code, tax, taxNum, phone, email, addr ->
                        viewModel.createBusiness(name, tagline, cat, symbol, code, tax, taxNum, phone, email, addr)
                    },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.SALES -> PointOfSaleScreen(
                    business = activeBusiness,
                    products = products,
                    contacts = contacts,
                    cart = cart,
                    selectedCustomer = selectedCustomer,
                    paymentMethod = paymentMethod,
                    onAddToCart = { viewModel.addToCart(it) },
                    onUpdateQuantity = { id, delta -> viewModel.updateCartQuantity(id, delta) },
                    onClearCart = { viewModel.clearCart() },
                    onSelectCustomer = { viewModel.setSelectedCustomer(it) },
                    onSelectPaymentMethod = { viewModel.setPaymentMethod(it) },
                    onCheckout = { tender -> viewModel.checkoutCurrentCart(tender) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.PURCHASES -> PurchasesScreen(
                    business = activeBusiness,
                    purchases = purchaseOrders,
                    suppliers = contacts,
                    products = products,
                    onRecordPurchase = { supp, items, method, paid, notes ->
                        viewModel.recordPurchaseBill(supp, items, method, paid, notes)
                    },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.PRODUCTS, AppScreen.INVENTORY -> InventoryScreen(
                    business = activeBusiness,
                    products = products,
                    inventoryValuation = inventoryValuation,
                    onAddProduct = { name, sku, barcode, cat, unit, cost, price, wholesale, stock, reorder, tax, batch, serial, variant ->
                        viewModel.addProduct(name, sku, barcode, cat, unit, cost, price, wholesale, stock, reorder, tax, batch, serial, variant)
                    },
                    onAdjustStock = { id, newStock, reason ->
                        viewModel.adjustStock(id, newStock, reason)
                    },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.CUSTOMERS -> ContactsLedgerScreen(
                    business = activeBusiness,
                    contacts = contacts.filter { it.type != "SUPPLIER" },
                    totalReceivables = receivables,
                    totalPayables = payables,
                    onAddContact = { name, type, phone, email, address, limit ->
                        viewModel.addContact(name, type, phone, email, address, limit)
                    },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.SUPPLIERS -> ContactsLedgerScreen(
                    business = activeBusiness,
                    contacts = contacts.filter { it.type != "CUSTOMER" },
                    totalReceivables = receivables,
                    totalPayables = payables,
                    onAddContact = { name, type, phone, email, address, limit ->
                        viewModel.addContact(name, type, phone, email, address, limit)
                    },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.PAYMENTS -> CashAndBankScreen(
                    business = activeBusiness,
                    cashBalance = cashBalance,
                    bankBalance = bankBalance,
                    ledgerEntries = ledgerEntries,
                    onTransferFunds = { from, to, amt, memo -> viewModel.recordJournalEntry(to, from, amt, memo) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.CASH_BANK -> CashAndBankScreen(
                    business = activeBusiness,
                    cashBalance = cashBalance,
                    bankBalance = bankBalance,
                    ledgerEntries = ledgerEntries,
                    onTransferFunds = { from, to, amt, memo -> viewModel.recordJournalEntry(to, from, amt, memo) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.INCOME_EXPENSES -> AuditFinancialReportsScreen(
                    business = activeBusiness,
                    orders = orders,
                    ledgerEntries = ledgerEntries,
                    auditLogs = auditLogs,
                    revenue = revenue,
                    expenses = expenses,
                    onRecordExpense = { title, amt, cat -> viewModel.recordExpense(title, amt, cat) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.ACCOUNTING -> ProfessionalModeDashboard(
                    business = activeBusiness,
                    revenue = revenue,
                    expenses = expenses,
                    inventoryValuation = inventoryValuation,
                    cashBalance = cashBalance,
                    bankBalance = bankBalance,
                    receivables = receivables,
                    payables = payables,
                    ledgerEntries = ledgerEntries,
                    products = products,
                    onNavigate = { viewModel.navigateTo(it) },
                    onRecordJournalEntry = { dr, cr, amt, desc -> viewModel.recordJournalEntry(dr, cr, amt, desc) },
                    onToggleReconciliation = { id, rec -> viewModel.toggleLedgerReconciliation(id, rec) },
                    onSwitchMode = { viewModel.toggleOperatingMode() },
                    modifier = screenModifier
                )

                AppScreen.REMINDER_CENTER -> SmartReminderCenterScreen(
                    business = activeBusiness,
                    contacts = contacts,
                    products = products,
                    ledgerEntries = ledgerEntries,
                    onNavigate = { viewModel.navigateTo(it) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.REPORTS_ANALYTICS -> AuditFinancialReportsScreen(
                    business = activeBusiness,
                    orders = orders,
                    ledgerEntries = ledgerEntries,
                    auditLogs = auditLogs,
                    revenue = revenue,
                    expenses = expenses,
                    onRecordExpense = { title, amt, cat -> viewModel.recordExpense(title, amt, cat) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.EMPLOYEES -> EmployeesScreen(
                    business = activeBusiness,
                    employees = employees,
                    onAddEmployee = { name, role, phone, email, sal, pin -> viewModel.addEmployee(name, role, phone, email, sal, pin) },
                    onDeleteEmployee = { viewModel.deleteEmployee(it) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.AI_ASSISTANT -> AiAssistantScreen(
                    business = activeBusiness,
                    revenue = revenue,
                    expenses = expenses,
                    inventoryValuation = inventoryValuation,
                    cashBalance = cashBalance,
                    bankBalance = bankBalance,
                    receivables = receivables,
                    payables = payables,
                    orders = orders,
                    products = products,
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.DOCUMENTS -> DocumentsScreen(
                    business = activeBusiness,
                    orders = orders,
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.SETTINGS -> SettingsScreen(
                    business = activeBusiness,
                    operatingMode = operatingMode,
                    onSetMode = { viewModel.setOperatingMode(it) },
                    isReducedMotion = isReducedMotion,
                    onToggleReducedMotion = { viewModel.toggleReducedMotion() },
                    productCount = products.size,
                    orderCount = orders.size,
                    ledgerCount = ledgerEntries.size,
                    onNavigate = { viewModel.navigateTo(it) },
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )

                AppScreen.SYSTEM_ARCHITECTURE -> ArchitectureViewerScreen(
                    onBack = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    modifier = screenModifier
                )
            }
        }
    }
}

@Composable
fun LiquidGlassBottomDock(
    currentScreen: AppScreen,
    operatingMode: AppOperatingMode,
    onNavigate: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        GlassFloatingDock(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 540.dp)
                .testTag("main_bottom_nav")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassDockTab(
                    selected = currentScreen == AppScreen.DASHBOARD,
                    onClick = { onNavigate(AppScreen.DASHBOARD) },
                    icon = Icons.Default.Dashboard,
                    label = "Home",
                    testTag = "nav_tab_dashboard"
                )
                GlassDockTab(
                    selected = currentScreen == AppScreen.SALES,
                    onClick = { onNavigate(AppScreen.SALES) },
                    icon = Icons.Default.PointOfSale,
                    label = "Sales",
                    testTag = "nav_tab_sales"
                )
                GlassDockTab(
                    selected = currentScreen == AppScreen.PURCHASES,
                    onClick = { onNavigate(AppScreen.PURCHASES) },
                    icon = Icons.Default.ShoppingCart,
                    label = "Purchases",
                    testTag = "nav_tab_purchases"
                )
                GlassDockTab(
                    selected = currentScreen == AppScreen.INVENTORY,
                    onClick = { onNavigate(AppScreen.INVENTORY) },
                    icon = Icons.Default.Inventory2,
                    label = "Stock",
                    testTag = "nav_tab_inventory"
                )
                val isReportsSelected = currentScreen == AppScreen.ACCOUNTING || currentScreen == AppScreen.REPORTS_ANALYTICS
                GlassDockTab(
                    selected = isReportsSelected,
                    onClick = {
                        if (operatingMode == AppOperatingMode.PROFESSIONAL) {
                            onNavigate(AppScreen.ACCOUNTING)
                        } else {
                            onNavigate(AppScreen.REPORTS_ANALYTICS)
                        }
                    },
                    icon = Icons.Default.Assessment,
                    label = if (operatingMode == AppOperatingMode.PROFESSIONAL) "Ledger" else "Reports",
                    testTag = "nav_tab_reports"
                )
            }
        }
    }
}

@Composable
private fun GlassDockTab(
    selected: Boolean,
    onClick: () -> Unit,
    icon: ImageVector,
    label: String,
    testTag: String
) {
    val isDark = isSystemInDarkTheme()
    val activeColor = if (isDark) Color(0xFF00E5FF) else MaterialTheme.colorScheme.primary
    val inactiveColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (selected) {
            if (isDark) Color(0x3300E5FF) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
        } else Color.Transparent,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) activeColor else inactiveColor,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) activeColor else inactiveColor
            )
        }
    }
}
