package com.example.ultimatebusinessos.domain.model

enum class BusinessModule(
    val code: String,
    val title: String,
    val description: String,
    val isCore: Boolean = false
) {
    POS("POS", "Point of Sale & Fast Billing", "Quick barcode/touch billing, receipts, cash drawer", isCore = true),
    INVENTORY("INVENTORY", "Inventory & Stock Control", "Stock alerts, low-inventory notifications, reorder limits", isCore = true),
    LEDGER("LEDGER", "Double-Entry Financial Ledger", "Audited financial transactions, debit/credit entries, cash flows", isCore = true),
    CUSTOMERS("CUSTOMERS", "Customer & Supplier CRM", "Credit balances, phone contacts, purchase histories", isCore = true),
    REPORTS("REPORTS", "Financial & Tax Analytics", "P&L statements, net profit calculations, tax summaries", isCore = true),
    AUDIT("AUDIT", "Immutable Security & Audit Trail", "Tamper-evident logs of every transaction and edit", isCore = true),

    // Specialized Industry Modules
    BATCH_EXPIRY("EXPIRY", "Batch & Expiry Date Tracker", "Crucial for pharmacies, grocery, perishables, and cosmetics"),
    IMEI_SERIAL("IMEI_SERIAL", "IMEI & Serial Number Tracker", "Track individual electronics, warranty cards, and devices"),
    VARIANTS("VARIANTS", "Matrix Variants (Size / Color)", "For apparel, shoes, and multi-attribute merchandise"),
    TABLE_KITCHEN("TABLE_KITCHEN", "Table Management & Kitchen Orders", "Dine-in table tabs, kitchen tickets, chef status"),
    JEWELRY_SPECS("JEWELRY", "Karat Purity & Weight Calculation", "Gold/silver live rate calculation, making charges"),
    BOM_MANUFACTURING("MANUFACTURING", "Bill of Materials (BOM) & Work Orders", "Convert raw materials into finished goods with cost rollup"),
    SERVICE_TICKETS("SERVICE_TICKETS", "Job Cards & Service Invoicing", "Auto repair, IT servicing, equipment maintenance"),
    TIER_PRICING("TIER_PRICING", "Wholesale Tier Pricing & Bulk Volume", "Custom rates for distributors, wholesalers, retailers")
}
