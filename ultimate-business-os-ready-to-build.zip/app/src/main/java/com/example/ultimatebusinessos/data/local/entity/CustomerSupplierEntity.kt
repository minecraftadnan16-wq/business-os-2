package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "contacts_ledger",
    foreignKeys = [
        ForeignKey(
            entity = BusinessProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["businessId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["businessId", "type"])
    ]
)
data class CustomerSupplierEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val type: String, // "CUSTOMER", "SUPPLIER", "BOTH"
    val name: String,
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val creditLimit: Double = 0.0,
    val currentBalance: Double = 0.0, // Positive: Customer owes business; Negative: Business owes supplier
    val notes: String = "",
    val createdAtEpoch: Long = System.currentTimeMillis()
)
