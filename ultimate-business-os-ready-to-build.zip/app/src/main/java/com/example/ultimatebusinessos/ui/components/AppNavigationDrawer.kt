package com.example.ultimatebusinessos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.ui.viewmodel.AppOperatingMode
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen

@Composable
fun AppNavigationDrawer(
    currentScreen: AppScreen,
    operatingMode: AppOperatingMode,
    activeBusiness: BusinessProfileEntity?,
    onSelectScreen: (AppScreen) -> Unit,
    onToggleMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()

    ModalDrawerSheet(
        modifier = modifier
            .width(320.dp)
            .testTag("app_navigation_drawer"),
        drawerContainerColor = if (isDark) Color(0xF5080E20) else Color(0xF8F8FAFC)
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Profile Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Business,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeBusiness?.businessName ?: "Ultimate Business OS",
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1
                            )
                            Text(
                                text = activeBusiness?.category ?: "Enterprise Edition",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Mode Switcher Banner in Drawer
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onToggleMode)
                            .testTag("drawer_mode_toggle_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = operatingMode.title.uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (operatingMode == AppOperatingMode.SIMPLE) "Tap for Professional Mode" else "Tap for Simple Mode",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Switch Mode",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Sections (All 18 Destinations)
            DrawerSectionHeader("CORE OPERATIONS")
            DrawerItem(AppScreen.DASHBOARD, Icons.Default.Dashboard, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.MY_BUSINESSES, Icons.Default.Store, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.SALES, Icons.Default.PointOfSale, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.PURCHASES, Icons.Default.ShoppingCart, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.PRODUCTS, Icons.Default.Category, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.INVENTORY, Icons.Default.Inventory, currentScreen, onSelectScreen)

            Spacer(modifier = Modifier.height(10.dp))
            DrawerSectionHeader("CRM & PEOPLE")
            DrawerItem(AppScreen.CUSTOMERS, Icons.Default.People, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.SUPPLIERS, Icons.Default.Business, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.EMPLOYEES, Icons.Default.Badge, currentScreen, onSelectScreen)

            Spacer(modifier = Modifier.height(10.dp))
            DrawerSectionHeader("FINANCE & LEDGER")
            DrawerItem(AppScreen.PAYMENTS, Icons.Default.Payment, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.CASH_BANK, Icons.Default.AccountBalance, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.INCOME_EXPENSES, Icons.Default.Receipt, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.ACCOUNTING, Icons.Default.TrendingUp, currentScreen, onSelectScreen)

            Spacer(modifier = Modifier.height(10.dp))
            DrawerSectionHeader("INTELLIGENCE & INSIGHTS")
            DrawerItem(AppScreen.REMINDER_CENTER, Icons.Default.NotificationsActive, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.REPORTS_ANALYTICS, Icons.Default.Assessment, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.AI_ASSISTANT, Icons.Default.AutoAwesome, currentScreen, onSelectScreen)

            Spacer(modifier = Modifier.height(10.dp))
            DrawerSectionHeader("SYSTEM & TOOLS")
            DrawerItem(AppScreen.DOCUMENTS, Icons.Default.Description, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.SETTINGS, Icons.Default.Settings, currentScreen, onSelectScreen)
            DrawerItem(AppScreen.SYSTEM_ARCHITECTURE, Icons.Default.Security, currentScreen, onSelectScreen)

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DrawerSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.outline,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun DrawerItem(
    screen: AppScreen,
    icon: ImageVector,
    currentScreen: AppScreen,
    onSelectScreen: (AppScreen) -> Unit
) {
    val isSelected = currentScreen == screen
    NavigationDrawerItem(
        label = { Text(screen.label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
        selected = isSelected,
        onClick = { onSelectScreen(screen) },
        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp)) },
        modifier = Modifier
            .padding(NavigationDrawerItemDefaults.ItemPadding)
            .testTag("drawer_item_${screen.name.lowercase()}"),
        shape = RoundedCornerShape(10.dp)
    )
}
