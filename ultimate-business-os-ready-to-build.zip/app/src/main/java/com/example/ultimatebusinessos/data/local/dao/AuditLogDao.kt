package com.example.ultimatebusinessos.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.ultimatebusinessos.data.local.entity.AuditLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM system_audit_logs WHERE businessId = :businessId ORDER BY timestampEpoch DESC")
    fun getLogsForBusiness(businessId: Long): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity): Long

    @Query("SELECT COUNT(*) FROM system_audit_logs WHERE businessId = :businessId")
    fun getLogCount(businessId: Long): Flow<Int>
}
