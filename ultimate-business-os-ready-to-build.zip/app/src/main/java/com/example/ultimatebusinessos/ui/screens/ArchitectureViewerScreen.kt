package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.domain.model.BusinessCategory
import com.example.ultimatebusinessos.domain.model.BusinessModule

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ArchitectureViewerScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(BusinessCategory.RETAIL) }
    var selectedTab by remember { mutableStateOf("18 Industries") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("architecture_viewer_screen")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "System Architecture Blueprint",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Phase 1: Product Definition & Multi-Industry Engine",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        HorizontalDivider()

        // Tab Selector
        LazyRow(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("18 Industries", "Core Architecture", "Data & Security", "Capabilities & Limits").forEach { tab ->
                item {
                    FilterChip(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        label = { Text(tab) }
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (selectedTab) {
                "18 Industries" -> {
                    item {
                        Text(
                            text = "Supported Industry Models (18 Presets)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Select any business type below to inspect its specialized database attributes and module configuration.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(BusinessCategory.values()) { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat.title, fontSize = 12.sp) }
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = selectedCategory.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = selectedCategory.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Specialized Field: ${selectedCategory.specializedTag}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Default Baseline Tax: ${selectedCategory.defaultTaxRate}%",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Recommended Modules:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    selectedCategory.recommendedModules.forEach { mod ->
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surface
                                        ) {
                                            Text(
                                                text = mod,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = "All Available System Modules",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(BusinessModule.values()) { mod ->
                        OutlinedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(if (mod.isCore) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (mod.isCore) Icons.Default.CheckCircle else Icons.Default.DataObject,
                                        contentDescription = null,
                                        tint = if (mod.isCore) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = mod.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        if (mod.isCore) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            ) {
                                                Text(
                                                    text = "CORE",
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(text = mod.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                "Core Architecture" -> {
                    item {
                        ArchitectureSectionCard(
                            icon = Icons.Default.PhoneAndroid,
                            title = "1. Frontend Architecture",
                            points = listOf(
                                "UI Framework: Jetpack Compose with strict Material Design 3 guidelines.",
                                "Architecture Pattern: MVVM (Model-View-ViewModel) with Unidirectional Data Flow (UDF).",
                                "State Management: Kotlin Coroutines StateFlow and SharedFlow for single-shot UI events.",
                                "Form Factor Adaptability: Window Size Classes with responsive layouts for phones, foldables, and tablets.",
                                "Edge-to-Edge: Mandatory enableEdgeToEdge() with WindowInsets safe drawing and navigation bar pads."
                            )
                        )
                    }

                    item {
                        ArchitectureSectionCard(
                            icon = Icons.Default.Memory,
                            title = "2. Backend & Data Layer Architecture",
                            points = listOf(
                                "Engine: Embedded SQLite via Room persistence library.",
                                "Concurrency: Kotlin Dispatchers.IO with Room transactions (withTransaction).",
                                "Isolation: Multi-tenant database design where businessId partitions all tables (products, orders, ledger, audit).",
                                "Financial Calculation Engine: FinancialCalculator with strict HALF_UP rounding and zero hardcoding."
                            )
                        )
                    }

                    item {
                        ArchitectureSectionCard(
                            icon = Icons.Default.Sync,
                            title = "3. Offline Architecture",
                            points = listOf(
                                "First-Class Offline: 100% of read and write operations execute locally without internet dependency.",
                                "WAL (Write-Ahead Logging): High-throughput concurrent POS reads during heavy cashier transactions.",
                                "Reliable Outbox Pattern: Transactions are committed locally first with cryptographic hash chains."
                            )
                        )
                    }
                }

                "Data & Security" -> {
                    item {
                        ArchitectureSectionCard(
                            icon = Icons.Default.Storage,
                            title = "4. Database Architecture & Schema",
                            points = listOf(
                                "business_profiles: Multi-store entities with currency, tax rate, and active module flags.",
                                "products: Unified catalog with SKU/Barcode indexes and specialized fields (batch, serial, variant).",
                                "contacts_ledger: Customer and supplier records with credit limits and net debtor/creditor balances.",
                                "order_invoices & order_items: Audited transaction records with line totals, discounts, and payment methods.",
                                "financial_ledger: Double-entry debit/credit ledger tracking cash, receivables, sales revenue, and expenses.",
                                "system_audit_logs: Tamper-evident immutable audit log of every creation, deletion attempt, and stock adjustment."
                            )
                        )
                    }

                    item {
                        ArchitectureSectionCard(
                            icon = Icons.Default.Lock,
                            title = "5. Security & Audit Non-Repudiation",
                            points = listOf(
                                "Rule 8 Compliance: Secure authorization, input validation, and cryptographic hash verification.",
                                "Rule 9 Compliance: Non-destructive financial history. No silent deletions or updates.",
                                "Receipt Hashing: Each invoice computes a SHA-256 seal chaining to the previous receipt hash."
                            )
                        )
                    }
                }

                "Capabilities & Limits" -> {
                    item {
                        ArchitectureSectionCard(
                            icon = Icons.Default.Info,
                            title = "Honest Platform Capabilities & Limitations",
                            points = listOf(
                                "Local Capacity: Modern Android SQLite databases comfortably store millions of rows on-device.",
                                "Hardware: Barcode scanning, camera integration, and ESC/POS thermal printing require device permissions.",
                                "Cloud Sync: Can be layered seamlessly with Firebase Firestore or cloud backends when requested.",
                                "Rule 10 Compliance: Never claim external hardware or cloud servers are active unless provisioned and tested."
                            )
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun ArchitectureSectionCard(
    icon: ImageVector,
    title: String,
    points: List<String>
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            points.forEach { pt ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "•",
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(
                        text = pt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
