package com.example.ultimatebusinessos.domain.calculation

import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest

object FinancialCalculator {

    fun round(value: Double, decimals: Int = 2): Double {
        if (value.isNaN() || value.isInfinite()) return 0.0
        return BigDecimal(value.toString())
            .setScale(decimals, RoundingMode.HALF_UP)
            .toDouble()
    }

    data class LineItemCalculation(
        val rawSubtotal: Double,
        val discountAmount: Double,
        val taxableAmount: Double,
        val taxAmount: Double,
        val lineTotal: Double,
        val costTotal: Double,
        val grossProfit: Double
    )

    fun calculateLineItem(
        quantity: Double,
        unitPrice: Double,
        costPrice: Double,
        discountPercent: Double,
        taxRatePercent: Double
    ): LineItemCalculation {
        val qty = if (quantity < 0.0) 0.0 else quantity
        val price = if (unitPrice < 0.0) 0.0 else unitPrice
        val cost = if (costPrice < 0.0) 0.0 else costPrice

        val rawSubtotal = round(qty * price)
        val clampedDiscount = discountPercent.coerceIn(0.0, 100.0)
        val discountAmount = round(rawSubtotal * (clampedDiscount / 100.0))
        val taxableAmount = round(rawSubtotal - discountAmount)

        val clampedTax = if (taxRatePercent < 0.0) 0.0 else taxRatePercent
        val taxAmount = round(taxableAmount * (clampedTax / 100.0))
        val lineTotal = round(taxableAmount + taxAmount)

        val costTotal = round(qty * cost)
        val grossProfit = round(taxableAmount - costTotal)

        return LineItemCalculation(
            rawSubtotal = rawSubtotal,
            discountAmount = discountAmount,
            taxableAmount = taxableAmount,
            taxAmount = taxAmount,
            lineTotal = lineTotal,
            costTotal = costTotal,
            grossProfit = grossProfit
        )
    }

    data class InvoiceCalculation(
        val subtotal: Double,
        val totalDiscount: Double,
        val taxableAmount: Double,
        val totalTax: Double,
        val grandTotal: Double,
        val totalCogs: Double,
        val grossProfit: Double,
        val balanceDue: Double
    )

    fun calculateInvoice(
        lines: List<LineItemCalculation>,
        additionalDiscountAmount: Double = 0.0,
        amountPaid: Double = 0.0
    ): InvoiceCalculation {
        var subtotal = 0.0
        var totalDiscount = 0.0
        var taxable = 0.0
        var totalTax = 0.0
        var totalCogs = 0.0

        for (line in lines) {
            subtotal += line.rawSubtotal
            totalDiscount += line.discountAmount
            taxable += line.taxableAmount
            totalTax += line.taxAmount
            totalCogs += line.costTotal
        }

        totalDiscount += additionalDiscountAmount
        val finalTaxable = (taxable - additionalDiscountAmount).coerceAtLeast(0.0)
        val grandTotal = round(finalTaxable + totalTax)
        val grossProfit = round(finalTaxable - totalCogs)
        val balanceDue = round((grandTotal - amountPaid).coerceAtLeast(0.0))

        return InvoiceCalculation(
            subtotal = round(subtotal),
            totalDiscount = round(totalDiscount),
            taxableAmount = round(finalTaxable),
            totalTax = round(totalTax),
            grandTotal = grandTotal,
            totalCogs = round(totalCogs),
            grossProfit = grossProfit,
            balanceDue = balanceDue
        )
    }

    /**
     * Computes a cryptographic SHA-256 seal for an invoice to guarantee immutability
     * and tamper-detection in the financial audit log.
     */
    fun generateInvoiceTamperSeal(
        previousReceiptHash: String,
        businessId: Long,
        invoiceNumber: String,
        timestampEpoch: Long,
        grandTotal: Double
    ): String {
        val payload = "$previousReceiptHash|$businessId|$invoiceNumber|$timestampEpoch|${"%.2f".format(grandTotal)}"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(payload.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(16).uppercase()
    }
}
