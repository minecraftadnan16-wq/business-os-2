package com.example.ultimatebusinessos.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerSupplierDao {
    @Query("SELECT * FROM contacts_ledger WHERE businessId = :businessId ORDER BY name ASC")
    fun getContactsForBusiness(businessId: Long): Flow<List<CustomerSupplierEntity>>

    @Query("SELECT * FROM contacts_ledger WHERE businessId = :businessId AND type = :type ORDER BY name ASC")
    fun getContactsByType(businessId: Long, type: String): Flow<List<CustomerSupplierEntity>>

    @Query("SELECT * FROM contacts_ledger WHERE id = :id LIMIT 1")
    suspend fun getContactById(id: Long): CustomerSupplierEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: CustomerSupplierEntity): Long

    @Update
    suspend fun updateContact(contact: CustomerSupplierEntity)

    @Query("UPDATE contacts_ledger SET currentBalance = currentBalance + :delta WHERE id = :id")
    suspend fun adjustBalance(id: Long, delta: Double)

    @Query("SELECT SUM(currentBalance) FROM contacts_ledger WHERE businessId = :businessId AND currentBalance > 0")
    fun getTotalReceivables(businessId: Long): Flow<Double?>

    @Query("SELECT SUM(ABS(currentBalance)) FROM contacts_ledger WHERE businessId = :businessId AND currentBalance < 0")
    fun getTotalPayables(businessId: Long): Flow<Double?>
}
