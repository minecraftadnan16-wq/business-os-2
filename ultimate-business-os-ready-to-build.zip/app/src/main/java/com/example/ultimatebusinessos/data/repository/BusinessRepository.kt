package com.example.ultimatebusinessos.data.repository

import androidx.room.withTransaction
import com.example.ultimatebusinessos.data.local.AppDatabase
import com.example.ultimatebusinessos.data.local.entity.AuditLogEntity
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import com.example.ultimatebusinessos.data.local.entity.OrderInvoiceEntity
import com.example.ultimatebusinessos.data.local.entity.OrderItemEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.domain.calculation.FinancialCalculator
import com.example.ultimatebusinessos.domain.model.BusinessCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext

class BusinessRepository(private val db: AppDatabase) {

    private val _activeBusiness = MutableStateFlow<BusinessProfileEntity?>(null)
    val activeBusiness: StateFlow<BusinessProfileEntity?> = _activeBusiness.asStateFlow()

    val allBusinesses: Flow<List<BusinessProfileEntity>> = db.businessDao().getAllBusinesses()

    suspend fun initialize() = withContext(Dispatchers.IO) {
        val existingCount = db.businessDao().countBusinesses()
        if (existingCount == 0) {
            // Seed initial primary business (Retail)
            val defaultBizId = db.businessDao().insertBusiness(
                BusinessProfileEntity(
                    businessName = "Apex Retail & Wholesale",
                    tagline = "General Merchandising & Store Front",
                    category = BusinessCategory.RETAIL.name,
                    currencySymbol = "$",
                    currencyCode = "USD",
                    defaultTaxRate = 5.0,
                    taxNumber = "US-TAX-849102",
                    phone = "+1 (555) 019-2834",
                    email = "sales@apexretail.os",
                    address = "100 Market Street, Suite 400",
                    activeModulesCsv = BusinessCategory.RETAIL.recommendedModules.joinToString(","),
                    isPrimary = true
                )
            )

            // Seed sample inventory for this business
            val sampleProducts = listOf(
                ProductEntity(
                    businessId = defaultBizId,
                    sku = "RET-001",
                    barcode = "890123456001",
                    name = "Premium Cotton Crewneck T-Shirt",
                    category = "Apparel",
                    unit = "pcs",
                    costPrice = 12.0,
                    sellingPrice = 28.0,
                    wholesalePrice = 20.0,
                    currentStock = 45.0,
                    reorderAlertLevel = 10.0,
                    taxRatePercent = 5.0,
                    variantSizeColor = "Navy / Large"
                ),
                ProductEntity(
                    businessId = defaultBizId,
                    sku = "RET-002",
                    barcode = "890123456002",
                    name = "Wireless Noise-Canceling Earbuds",
                    category = "Electronics",
                    unit = "pcs",
                    costPrice = 35.0,
                    sellingPrice = 79.99,
                    wholesalePrice = 55.0,
                    currentStock = 18.0,
                    reorderAlertLevel = 5.0,
                    taxRatePercent = 5.0,
                    serialNumber = "SN-ANC-99214"
                ),
                ProductEntity(
                    businessId = defaultBizId,
                    sku = "RET-003",
                    barcode = "890123456003",
                    name = "Artisan Ground Espresso Roast (500g)",
                    category = "Food & Grocery",
                    unit = "bag",
                    costPrice = 6.50,
                    sellingPrice = 14.50,
                    wholesalePrice = 10.0,
                    currentStock = 32.0,
                    reorderAlertLevel = 8.0,
                    taxRatePercent = 0.0,
                    batchNumber = "B-2026-X8",
                    expiryDateEpoch = System.currentTimeMillis() + (180L * 24 * 3600 * 1000)
                ),
                ProductEntity(
                    businessId = defaultBizId,
                    sku = "RET-004",
                    barcode = "890123456004",
                    name = "Fast USB-C 65W GaN Charger",
                    category = "Accessories",
                    unit = "pcs",
                    costPrice = 14.0,
                    sellingPrice = 32.0,
                    wholesalePrice = 22.0,
                    currentStock = 6.0,
                    reorderAlertLevel = 10.0, // Triggers low-stock alert
                    taxRatePercent = 5.0
                )
            )
            db.productDao().insertProducts(sampleProducts)

            // Seed sample contact
            db.customerSupplierDao().insertContact(
                CustomerSupplierEntity(
                    businessId = defaultBizId,
                    type = "CUSTOMER",
                    name = "Sarah Jenkins",
                    phone = "+1 (555) 749-2041",
                    email = "sarah.j@example.com",
                    address = "42 Elm Street, Springfield",
                    creditLimit = 500.0,
                    currentBalance = 45.0,
                    notes = "Preferred VIP Customer"
                )
            )
            db.customerSupplierDao().insertContact(
                CustomerSupplierEntity(
                    businessId = defaultBizId,
                    type = "SUPPLIER",
                    name = "Global Wholesale Mart",
                    phone = "+1 (555) 302-8841",
                    email = "orders@globalwholesalers.com",
                    address = "900 Industrial Parkway, Chicago",
                    creditLimit = 5000.0,
                    currentBalance = -180.0,
                    notes = "Primary merchandise vendor"
                )
            )

            // Seed sample team
            db.employeeDao().insertEmployees(
                listOf(
                    com.example.ultimatebusinessos.data.local.entity.EmployeeEntity(
                        businessId = defaultBizId,
                        name = "Adnan (You)",
                        role = "OWNER",
                        phone = "+1 (555) 100-2000",
                        email = "owner@ultimatebusinessos.com",
                        salary = 0.0,
                        pinCode = "1234"
                    ),
                    com.example.ultimatebusinessos.data.local.entity.EmployeeEntity(
                        businessId = defaultBizId,
                        name = "Elena Vance",
                        role = "CASHIER",
                        phone = "+1 (555) 100-2001",
                        email = "elena.v@example.com",
                        salary = 2400.0,
                        pinCode = "0000"
                    ),
                    com.example.ultimatebusinessos.data.local.entity.EmployeeEntity(
                        businessId = defaultBizId,
                        name = "Marcus Brody",
                        role = "MANAGER",
                        phone = "+1 (555) 100-2002",
                        email = "marcus.b@example.com",
                        salary = 4200.0,
                        pinCode = "9999"
                    )
                )
            )

            // Seed initial capital & bank balances in Double-Entry Ledger
            val nowTime = System.currentTimeMillis()
            db.ledgerDao().insertEntry(
                FinancialLedgerEntity(
                    businessId = defaultBizId,
                    transactionDateEpoch = nowTime - 86400000,
                    referenceType = "CAPITAL_INJECTION",
                    referenceId = "CAP-001",
                    accountDebit = "Cash On Hand",
                    accountCredit = "Owner's Equity",
                    amount = 2500.0,
                    description = "Initial opening cash float",
                    createdByUser = "System Bootstrapper",
                    isReconciled = true
                )
            )
            db.ledgerDao().insertEntry(
                FinancialLedgerEntity(
                    businessId = defaultBizId,
                    transactionDateEpoch = nowTime - 86400000,
                    referenceType = "CAPITAL_INJECTION",
                    referenceId = "CAP-002",
                    accountDebit = "Primary Bank Account",
                    accountCredit = "Owner's Equity",
                    amount = 12000.0,
                    description = "Initial business operating capital deposit",
                    createdByUser = "System Bootstrapper",
                    isReconciled = true
                )
            )

            // Write initial audit log
            db.auditLogDao().insertLog(
                AuditLogEntity(
                    businessId = defaultBizId,
                    action = "CREATE_BUSINESS",
                    entityType = "BUSINESS",
                    entityId = defaultBizId.toString(),
                    details = "Initialized business 'Apex Retail & Wholesale' with multi-industry modules",
                    actor = "System Bootstrapper"
                )
            )
        }

        // Set active business
        val primary = db.businessDao().getPrimaryBusiness() ?: db.businessDao().getFirstBusiness()
        _activeBusiness.value = primary
    }

    suspend fun switchBusiness(businessId: Long) = withContext(Dispatchers.IO) {
        val target = db.businessDao().getBusinessById(businessId)
        if (target != null) {
            db.businessDao().clearPrimaryFlag()
            db.businessDao().setPrimary(businessId)
            _activeBusiness.value = target.copy(isPrimary = true)

            db.auditLogDao().insertLog(
                AuditLogEntity(
                    businessId = businessId,
                    action = "SWITCH_BUSINESS",
                    entityType = "BUSINESS",
                    entityId = businessId.toString(),
                    details = "Switched active business context to '${target.businessName}'",
                    actor = "Current User"
                )
            )
        }
    }

    suspend fun createNewBusiness(
        name: String,
        tagline: String,
        category: BusinessCategory,
        currencySymbol: String,
        currencyCode: String,
        taxRate: Double,
        taxNumber: String,
        phone: String,
        email: String,
        address: String,
        activeModules: List<String>
    ): Long = withContext(Dispatchers.IO) {
        val newEntity = BusinessProfileEntity(
            businessName = name.ifBlank { "${category.title} Store" },
            tagline = tagline,
            category = category.name,
            currencySymbol = currencySymbol.ifBlank { "$" },
            currencyCode = currencyCode.ifBlank { "USD" },
            defaultTaxRate = taxRate,
            taxNumber = taxNumber,
            phone = phone,
            email = email,
            address = address,
            activeModulesCsv = activeModules.joinToString(","),
            isPrimary = false
        )
        val newId = db.businessDao().insertBusiness(newEntity)

        db.auditLogDao().insertLog(
            AuditLogEntity(
                businessId = newId,
                action = "CREATE_BUSINESS",
                entityType = "BUSINESS",
                entityId = newId.toString(),
                details = "Registered new business entity '$name' under category '${category.title}'",
                actor = "Business Owner"
            )
        )

        // Switch to this new business
        switchBusiness(newId)
        newId
    }

    // Active Business Scoped Data Flows
    fun getProducts(): Flow<List<ProductEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.productDao().getProductsForBusiness(biz.id)
    }

    fun getLowStockProducts(): Flow<List<ProductEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.productDao().getLowStockProducts(biz.id)
    }

    fun getContacts(): Flow<List<CustomerSupplierEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.customerSupplierDao().getContactsForBusiness(biz.id)
    }

    fun getOrders(): Flow<List<OrderInvoiceEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.orderDao().getOrdersForBusiness(biz.id)
    }

    fun getLedgerEntries(): Flow<List<FinancialLedgerEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.ledgerDao().getLedgerEntriesForBusiness(biz.id)
    }

    fun getAuditLogs(): Flow<List<AuditLogEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.auditLogDao().getLogsForBusiness(biz.id)
    }

    fun getInventoryValuation(): Flow<Double?> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(0.0) else db.productDao().getInventoryCostValuation(biz.id)
    }

    fun getTotalSalesRevenue(): Flow<Double?> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(0.0) else db.orderDao().getTotalSalesRevenue(biz.id)
    }

    fun getTotalExpenses(): Flow<Double?> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(0.0) else db.ledgerDao().getTotalExpenses(biz.id)
    }

    fun getTotalReceivables(): Flow<Double?> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(0.0) else db.customerSupplierDao().getTotalReceivables(biz.id)
    }

    fun getTotalPayables(): Flow<Double?> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(0.0) else db.customerSupplierDao().getTotalPayables(biz.id)
    }

    // Product Actions
    suspend fun addProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        val bizId = _activeBusiness.value?.id ?: 1L
        val entity = product.copy(businessId = bizId)
        val id = db.productDao().insertProduct(entity)

        db.auditLogDao().insertLog(
            AuditLogEntity(
                businessId = bizId,
                action = "CREATE_PRODUCT",
                entityType = "PRODUCT",
                entityId = id.toString(),
                details = "Added product '${product.name}' (SKU: ${product.sku}, Stock: ${product.currentStock})",
                actor = "User"
            )
        )
        id
    }

    suspend fun adjustStock(productId: Long, newStock: Double, reason: String) = withContext(Dispatchers.IO) {
        val bizId = _activeBusiness.value?.id ?: 1L
        val prod = db.productDao().getProductById(productId) ?: return@withContext
        val oldStock = prod.currentStock
        db.productDao().updateStock(productId, newStock)

        db.auditLogDao().insertLog(
            AuditLogEntity(
                businessId = bizId,
                action = "ADJUST_STOCK",
                entityType = "PRODUCT",
                entityId = productId.toString(),
                details = "Adjusted '${prod.name}' stock from $oldStock to $newStock. Reason: $reason",
                actor = "Inventory Controller"
            )
        )
    }

    // Customer & Supplier Actions
    suspend fun addContact(contact: CustomerSupplierEntity): Long = withContext(Dispatchers.IO) {
        val bizId = _activeBusiness.value?.id ?: 1L
        val id = db.customerSupplierDao().insertContact(contact.copy(businessId = bizId))

        db.auditLogDao().insertLog(
            AuditLogEntity(
                businessId = bizId,
                action = "CONTACT_ADDED",
                entityType = "CONTACT",
                entityId = id.toString(),
                details = "Registered ${contact.type.lowercase()} '${contact.name}' (Phone: ${contact.phone})",
                actor = "User"
            )
        )
        id
    }

    // POS & Sales Transaction: Full ACID Transaction
    data class CartItem(
        val product: ProductEntity,
        val quantity: Double,
        val unitPrice: Double,
        val discountPercent: Double = 0.0
    )

    suspend fun checkoutSale(
        cartItems: List<CartItem>,
        customer: CustomerSupplierEntity?,
        paymentMethod: String,
        amountPaid: Double,
        orderNotes: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        if (cartItems.isEmpty()) return@withContext Result.failure(Exception("Cart is empty"))

        try {
            var orderId = 0L
            db.withTransaction {
                // 1. Calculate line items
                val lineCalculations = cartItems.map { item ->
                    FinancialCalculator.calculateLineItem(
                        quantity = item.quantity,
                        unitPrice = item.unitPrice,
                        costPrice = item.product.costPrice,
                        discountPercent = item.discountPercent,
                        taxRatePercent = item.product.taxRatePercent
                    )
                }

                // 2. Calculate invoice totals
                val invoiceCalc = FinancialCalculator.calculateInvoice(
                    lines = lineCalculations,
                    amountPaid = amountPaid
                )

                val latestOrder = db.orderDao().getLatestOrder(biz.id)
                val prevHash = latestOrder?.receiptHash ?: "0000000000000000"
                val invoiceNumber = "INV-${System.currentTimeMillis() % 1000000}"
                val now = System.currentTimeMillis()

                val receiptHash = FinancialCalculator.generateInvoiceTamperSeal(
                    previousReceiptHash = prevHash,
                    businessId = biz.id,
                    invoiceNumber = invoiceNumber,
                    timestampEpoch = now,
                    grandTotal = invoiceCalc.grandTotal
                )

                val paymentStatus = when {
                    amountPaid >= invoiceCalc.grandTotal -> "PAID"
                    amountPaid > 0.0 -> "PARTIAL"
                    else -> "UNPAID"
                }

                // 3. Insert invoice
                val invoice = OrderInvoiceEntity(
                    businessId = biz.id,
                    invoiceNumber = invoiceNumber,
                    orderType = "SALE",
                    customerSupplierId = customer?.id,
                    customerSupplierName = customer?.name ?: "Walk-in Customer",
                    orderDateEpoch = now,
                    subtotal = invoiceCalc.subtotal,
                    discountAmount = invoiceCalc.totalDiscount,
                    taxAmount = invoiceCalc.totalTax,
                    grandTotal = invoiceCalc.grandTotal,
                    paidAmount = amountPaid,
                    balanceDue = invoiceCalc.balanceDue,
                    paymentMethod = paymentMethod,
                    paymentStatus = paymentStatus,
                    fulfillmentStatus = "COMPLETED",
                    notes = orderNotes,
                    receiptHash = receiptHash,
                    cashierName = "Cashier"
                )
                orderId = db.orderDao().insertOrder(invoice)

                // 4. Insert items and deduct stock
                val orderItems = cartItems.mapIndexed { idx, item ->
                    val line = lineCalculations[idx]
                    // Deduct stock if inventory tracked
                    db.productDao().deductStock(item.product.id, item.quantity)

                    OrderItemEntity(
                        orderId = orderId,
                        businessId = biz.id,
                        productId = item.product.id,
                        productName = item.product.name,
                        quantity = item.quantity,
                        unitPrice = item.unitPrice,
                        costPrice = item.product.costPrice,
                        discountPercent = item.discountPercent,
                        taxRatePercent = item.product.taxRatePercent,
                        lineTotal = line.lineTotal,
                        specializedDetail = item.product.variantSizeColor.ifBlank {
                            item.product.serialNumber.ifBlank { item.product.batchNumber }
                        }
                    )
                }
                db.orderDao().insertOrderItems(orderItems)

                // 5. Customer balance adjustment if unpaid balance
                if (customer != null && invoiceCalc.balanceDue > 0.0) {
                    db.customerSupplierDao().adjustBalance(customer.id, invoiceCalc.balanceDue)
                }

                // 6. Record Double-Entry Ledger Transactions
                // Cash / Asset Debit
                if (amountPaid > 0.0) {
                    val debitAccount = if (paymentMethod == "CASH") "Cash On Hand" else "Bank / Electronic"
                    db.ledgerDao().insertEntry(
                        FinancialLedgerEntity(
                            businessId = biz.id,
                            transactionDateEpoch = now,
                            referenceType = "INVOICE_SALE",
                            referenceId = invoiceNumber,
                            accountDebit = debitAccount,
                            accountCredit = "Sales Revenue",
                            amount = amountPaid,
                            description = "Payment for $invoiceNumber via $paymentMethod",
                            createdByUser = "Cashier"
                        )
                    )
                }

                // Accounts Receivable Debit for unpaid balance
                if (invoiceCalc.balanceDue > 0.0) {
                    db.ledgerDao().insertEntry(
                        FinancialLedgerEntity(
                            businessId = biz.id,
                            transactionDateEpoch = now,
                            referenceType = "INVOICE_SALE",
                            referenceId = invoiceNumber,
                            accountDebit = "Accounts Receivable",
                            accountCredit = "Sales Revenue",
                            amount = invoiceCalc.balanceDue,
                            description = "Credit due for $invoiceNumber (${customer?.name ?: "Customer"})",
                            createdByUser = "Cashier"
                        )
                    )
                }

                // 7. Write Audit Trail
                db.auditLogDao().insertLog(
                    AuditLogEntity(
                        businessId = biz.id,
                        action = "SALE_COMPLETED",
                        entityType = "ORDER",
                        entityId = invoiceNumber,
                        details = "Sale completed. Total: ${biz.currencySymbol}${invoiceCalc.grandTotal}, Paid: ${biz.currencySymbol}$amountPaid. Hash: $receiptHash",
                        actor = "Cashier",
                        integrityHash = receiptHash
                    )
                )
            }
            Result.success(orderId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Expense Recording
    suspend fun recordExpense(
        title: String,
        amount: Double,
        category: String,
        paymentAccount: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        try {
            val now = System.currentTimeMillis()
            val id = db.ledgerDao().insertEntry(
                FinancialLedgerEntity(
                    businessId = biz.id,
                    transactionDateEpoch = now,
                    referenceType = "EXPENSE",
                    referenceId = "EXP-${now % 1000000}",
                    accountDebit = "Operating Expense: $category",
                    accountCredit = paymentAccount,
                    amount = amount,
                    description = title,
                    createdByUser = "Manager"
                )
            )

            db.auditLogDao().insertLog(
                AuditLogEntity(
                    businessId = biz.id,
                    action = "EXPENSE_LOGGED",
                    entityType = "LEDGER",
                    entityId = id.toString(),
                    details = "Expense logged: $title (${biz.currencySymbol}$amount from $paymentAccount)",
                    actor = "Manager"
                )
            )
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Employees Flow
    fun getEmployees(): Flow<List<com.example.ultimatebusinessos.data.local.entity.EmployeeEntity>> = _activeBusiness.flatMapLatest { biz ->
        if (biz == null) flowOf(emptyList()) else db.employeeDao().getEmployeesForBusiness(biz.id)
    }

    suspend fun addEmployee(
        name: String,
        role: String,
        phone: String,
        email: String,
        salary: Double,
        pin: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        try {
            val emp = com.example.ultimatebusinessos.data.local.entity.EmployeeEntity(
                businessId = biz.id,
                name = name,
                role = role,
                phone = phone,
                email = email,
                salary = salary,
                pinCode = pin
            )
            val id = db.employeeDao().insertEmployee(emp)
            db.auditLogDao().insertLog(
                AuditLogEntity(
                    businessId = biz.id,
                    action = "ADD_EMPLOYEE",
                    entityType = "EMPLOYEE",
                    entityId = id.toString(),
                    details = "Registered employee '$name' with role '$role'",
                    actor = "Admin / Owner"
                )
            )
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteEmployee(employee: com.example.ultimatebusinessos.data.local.entity.EmployeeEntity) = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext
        db.employeeDao().deleteEmployee(employee)
        db.auditLogDao().insertLog(
            AuditLogEntity(
                businessId = biz.id,
                action = "DELETE_EMPLOYEE",
                entityType = "EMPLOYEE",
                entityId = employee.id.toString(),
                details = "Removed employee record '${employee.name}'",
                actor = "Admin / Owner"
            )
        )
    }

    // Purchase Bill Operation (ACID Transaction)
    suspend fun recordPurchaseBill(
        supplier: CustomerSupplierEntity?,
        items: List<CartItem>,
        paymentMethod: String,
        amountPaid: Double,
        notes: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        if (items.isEmpty()) return@withContext Result.failure(Exception("No items in purchase bill"))

        try {
            var orderId = 0L
            db.withTransaction {
                val subtotal = items.sumOf { it.quantity * it.unitPrice }
                val invoiceNumber = "PUR-${System.currentTimeMillis() % 1000000}"
                val now = System.currentTimeMillis()
                val balanceDue = (subtotal - amountPaid).coerceAtLeast(0.0)
                val paymentStatus = if (balanceDue <= 0.0) "PAID" else if (amountPaid > 0) "PARTIAL" else "UNPAID"

                val receiptHash = FinancialCalculator.generateInvoiceTamperSeal(
                    previousReceiptHash = "PURCHASE-RECEIPT",
                    businessId = biz.id,
                    invoiceNumber = invoiceNumber,
                    timestampEpoch = now,
                    grandTotal = subtotal
                )

                val purchaseInvoice = OrderInvoiceEntity(
                    businessId = biz.id,
                    invoiceNumber = invoiceNumber,
                    orderType = "PURCHASE",
                    customerSupplierId = supplier?.id,
                    customerSupplierName = supplier?.name ?: "Vendor Bill",
                    orderDateEpoch = now,
                    subtotal = subtotal,
                    discountAmount = 0.0,
                    taxAmount = 0.0,
                    grandTotal = subtotal,
                    paidAmount = amountPaid,
                    balanceDue = balanceDue,
                    paymentMethod = paymentMethod,
                    paymentStatus = paymentStatus,
                    fulfillmentStatus = "COMPLETED",
                    notes = notes,
                    receiptHash = receiptHash,
                    cashierName = "Purchasing Manager"
                )
                orderId = db.orderDao().insertOrder(purchaseInvoice)

                // Increase stock for each item & insert line records
                val orderItems = items.map { item ->
                    val prod = db.productDao().getProductById(item.product.id)
                    val newStock = (prod?.currentStock ?: 0.0) + item.quantity
                    db.productDao().updateStock(item.product.id, newStock)

                    OrderItemEntity(
                        orderId = orderId,
                        businessId = biz.id,
                        productId = item.product.id,
                        productName = item.product.name,
                        quantity = item.quantity,
                        unitPrice = item.unitPrice,
                        costPrice = item.unitPrice,
                        lineTotal = item.quantity * item.unitPrice
                    )
                }
                db.orderDao().insertOrderItems(orderItems)

                // Double entry: Dr Inventory Asset, Cr Cash/Bank or Accounts Payable
                if (amountPaid > 0.0) {
                    val crAccount = if (paymentMethod == "CASH") "Cash On Hand" else "Primary Bank Account"
                    db.ledgerDao().insertEntry(
                        FinancialLedgerEntity(
                            businessId = biz.id,
                            transactionDateEpoch = now,
                            referenceType = "PURCHASE_BILL",
                            referenceId = invoiceNumber,
                            accountDebit = "Inventory Asset",
                            accountCredit = crAccount,
                            amount = amountPaid,
                            description = "Stock replenishment from ${supplier?.name ?: "Supplier"}",
                            createdByUser = "Purchasing"
                        )
                    )
                }

                if (balanceDue > 0.0) {
                    db.ledgerDao().insertEntry(
                        FinancialLedgerEntity(
                            businessId = biz.id,
                            transactionDateEpoch = now,
                            referenceType = "PURCHASE_BILL",
                            referenceId = invoiceNumber,
                            accountDebit = "Inventory Asset",
                            accountCredit = "Accounts Payable",
                            amount = balanceDue,
                            description = "Credit purchase due to ${supplier?.name ?: "Supplier"}",
                            createdByUser = "Purchasing"
                        )
                    )

                    // Adjust supplier balance (negative = owed to supplier)
                    if (supplier != null) {
                        db.customerSupplierDao().adjustBalance(supplier.id, -balanceDue)
                    }
                }

                db.auditLogDao().insertLog(
                    AuditLogEntity(
                        businessId = biz.id,
                        action = "PURCHASE_RECORDED",
                        entityType = "PURCHASE",
                        entityId = invoiceNumber,
                        details = "Purchased ${items.size} stock items totaling ${biz.currencySymbol}$subtotal from ${supplier?.name ?: "Vendor"}",
                        actor = "Purchasing Manager",
                        integrityHash = receiptHash
                    )
                )
            }
            Result.success(orderId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Receive Money (Customer Debt Settlement)
    suspend fun receiveCustomerPayment(
        customer: CustomerSupplierEntity,
        amount: Double,
        destinationAccount: String,
        notes: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        if (amount <= 0.0) return@withContext Result.failure(Exception("Amount must be greater than zero"))

        try {
            var ledgerId = 0L
            db.withTransaction {
                val now = System.currentTimeMillis()
                val ref = "REC-${now % 1000000}"

                ledgerId = db.ledgerDao().insertEntry(
                    FinancialLedgerEntity(
                        businessId = biz.id,
                        transactionDateEpoch = now,
                        referenceType = "PAYMENT_RECEIVED",
                        referenceId = ref,
                        accountDebit = destinationAccount,
                        accountCredit = "Accounts Receivable",
                        amount = amount,
                        description = "Payment received from ${customer.name}. $notes",
                        createdByUser = "Cashier"
                    )
                )

                // Reduce customer's outstanding balance
                db.customerSupplierDao().adjustBalance(customer.id, -amount)

                db.auditLogDao().insertLog(
                    AuditLogEntity(
                        businessId = biz.id,
                        action = "PAYMENT_COLLECTED",
                        entityType = "CUSTOMER",
                        entityId = customer.id.toString(),
                        details = "Received ${biz.currencySymbol}$amount from ${customer.name} into $destinationAccount",
                        actor = "Cashier"
                    )
                )
            }
            Result.success(ledgerId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Pay Supplier Debt Settlement
    suspend fun paySupplierBill(
        supplier: CustomerSupplierEntity,
        amount: Double,
        sourceAccount: String,
        notes: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        if (amount <= 0.0) return@withContext Result.failure(Exception("Amount must be greater than zero"))

        try {
            var ledgerId = 0L
            db.withTransaction {
                val now = System.currentTimeMillis()
                val ref = "PAY-${now % 1000000}"

                ledgerId = db.ledgerDao().insertEntry(
                    FinancialLedgerEntity(
                        businessId = biz.id,
                        transactionDateEpoch = now,
                        referenceType = "SUPPLIER_PAYOUT",
                        referenceId = ref,
                        accountDebit = "Accounts Payable",
                        accountCredit = sourceAccount,
                        amount = amount,
                        description = "Settlement payment to ${supplier.name}. $notes",
                        createdByUser = "Accountant"
                    )
                )

                // Balance for supplier was negative (e.g. -500). Paying 200 adds +200 making balance -300.
                db.customerSupplierDao().adjustBalance(supplier.id, amount)

                db.auditLogDao().insertLog(
                    AuditLogEntity(
                        businessId = biz.id,
                        action = "SUPPLIER_PAID",
                        entityType = "SUPPLIER",
                        entityId = supplier.id.toString(),
                        details = "Disbursed ${biz.currencySymbol}$amount to supplier ${supplier.name} from $sourceAccount",
                        actor = "Accountant"
                    )
                )
            }
            Result.success(ledgerId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Professional Mode: Balanced Manual Journal Entry
    suspend fun recordJournalEntry(
        debitAccount: String,
        creditAccount: String,
        amount: Double,
        description: String
    ): Result<Long> = withContext(Dispatchers.IO) {
        val biz = _activeBusiness.value ?: return@withContext Result.failure(Exception("No active business"))
        if (amount <= 0.0) return@withContext Result.failure(Exception("Amount must be greater than zero"))
        if (debitAccount.isBlank() || creditAccount.isBlank() || debitAccount == creditAccount) {
            return@withContext Result.failure(Exception("Debit and Credit accounts must be distinct"))
        }

        try {
            val now = System.currentTimeMillis()
            val ref = "JV-${now % 1000000}"

            val id = db.ledgerDao().insertEntry(
                FinancialLedgerEntity(
                    businessId = biz.id,
                    transactionDateEpoch = now,
                    referenceType = "JOURNAL_VOUCHER",
                    referenceId = ref,
                    accountDebit = debitAccount,
                    accountCredit = creditAccount,
                    amount = amount,
                    description = description,
                    createdByUser = "Certified Accountant",
                    isReconciled = false
                )
            )

            db.auditLogDao().insertLog(
                AuditLogEntity(
                    businessId = biz.id,
                    action = "JOURNAL_ENTRY_POSTED",
                    entityType = "LEDGER",
                    entityId = ref,
                    details = "Journal voucher posted: Dr $debitAccount / Cr $creditAccount for ${biz.currencySymbol}$amount ($description)",
                    actor = "Certified Accountant"
                )
            )
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleLedgerReconciliation(ledgerId: Long, isReconciled: Boolean) = withContext(Dispatchers.IO) {
        db.ledgerDao().setReconciliation(ledgerId, isReconciled)
    }
}
