package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CashAndBankScreen(
    business: BusinessProfileEntity?,
    cashBalance: Double,
    bankBalance: Double,
    ledgerEntries: List<FinancialLedgerEntity>,
    onTransferFunds: (fromAccount: String, toAccount: String, amount: Double, memo: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = business?.currencySymbol ?: "$"
    var showTransferDialog by remember { mutableStateOf(false) }

    val liquidTotal = cashBalance + bankBalance

    val cashAndBankTransactions = remember(ledgerEntries) {
        ledgerEntries.filter {
            it.accountDebit == "Cash On Hand" || it.accountCredit == "Cash On Hand" ||
            it.accountDebit == "Primary Bank Account" || it.accountCredit == "Primary Bank Account"
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("cash_bank_screen")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Cash and Bank Accounts",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Total Liquidity: $currency${"%.2f".format(liquidTotal)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            OutlinedButton(onClick = { showTransferDialog = true }) {
                Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Transfer")
            }
        }

        HorizontalDivider()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Account Balances Cards
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AccountCard(
                        title = "Cash In Drawer",
                        subtitle = "Physical cash float",
                        balance = "$currency${"%.2f".format(cashBalance)}",
                        icon = Icons.Default.Payments,
                        color = Color(0xFF0D9488),
                        modifier = Modifier.weight(1f)
                    )
                    AccountCard(
                        title = "Primary Bank",
                        subtitle = "Commercial checking",
                        balance = "$currency${"%.2f".format(bankBalance)}",
                        icon = Icons.Default.AccountBalance,
                        color = Color(0xFF2563EB),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Cash & Bank Ledger History", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            }

            if (cashAndBankTransactions.isEmpty()) {
                item {
                    Text("No cash or bank transactions yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(cashAndBankTransactions) { entry ->
                    val isCashInflow = entry.accountDebit == "Cash On Hand" || entry.accountDebit == "Primary Bank Account"
                    val dateStr = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(entry.transactionDateEpoch))

                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isCashInflow) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isCashInflow) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (isCashInflow) Color(0xFF059669) else Color(0xFFDC2626),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(entry.description, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Dr: ${entry.accountDebit}  |  Cr: ${entry.accountCredit} • $dateStr", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Text(
                                text = "${if (isCashInflow) "+" else "-"}$currency${"%.2f".format(entry.amount)}",
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isCashInflow) Color(0xFF059669) else Color(0xFFDC2626)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showTransferDialog) {
        TransferFundsDialog(
            currency = currency,
            cashBalance = cashBalance,
            bankBalance = bankBalance,
            onDismiss = { showTransferDialog = false },
            onConfirm = { from, to, amt, memo ->
                onTransferFunds(from, to, amt, memo)
                showTransferDialog = false
            }
        )
    }
}

@Composable
fun AccountCard(
    title: String,
    subtitle: String,
    balance: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(balance, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge, color = color)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
fun TransferFundsDialog(
    currency: String,
    cashBalance: Double,
    bankBalance: Double,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Double, String) -> Unit
) {
    var transferType by remember { mutableStateOf(0) } // 0: Deposit (Cash -> Bank), 1: Withdraw (Bank -> Cash)
    var amountInput by remember { mutableStateOf("") }
    var memo by remember { mutableStateOf("") }

    val fromAccount = if (transferType == 0) "Cash On Hand" else "Primary Bank Account"
    val toAccount = if (transferType == 0) "Primary Bank Account" else "Cash On Hand"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Transfer Funds") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { transferType = 0 },
                        colors = if (transferType == 0) androidx.compose.material3.ButtonDefaults.buttonColors() else androidx.compose.material3.ButtonDefaults.outlinedButtonColors(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Deposit Cash to Bank", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { transferType = 1 },
                        colors = if (transferType == 1) androidx.compose.material3.ButtonDefaults.buttonColors() else androidx.compose.material3.ButtonDefaults.outlinedButtonColors(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Withdraw from Bank", fontSize = 11.sp)
                    }
                }

                Text("From: $fromAccount -> To: $toAccount", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Transfer Amount ($currency) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = memo,
                    onValueChange = { memo = it },
                    label = { Text("Memo / Reference") },
                    placeholder = { Text("e.g. End of day cash bank deposit") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull()
                    if (amt != null && amt > 0.0) {
                        onConfirm(fromAccount, toAccount, amt, memo.ifBlank { "Inter-account transfer" })
                    }
                }
            ) {
                Text("Confirm Transfer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
