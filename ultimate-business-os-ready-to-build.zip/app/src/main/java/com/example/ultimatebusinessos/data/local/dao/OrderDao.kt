package com.example.ultimatebusinessos.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.ultimatebusinessos.data.local.entity.OrderInvoiceEntity
import com.example.ultimatebusinessos.data.local.entity.OrderItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM order_invoices WHERE businessId = :businessId ORDER BY orderDateEpoch DESC")
    fun getOrdersForBusiness(businessId: Long): Flow<List<OrderInvoiceEntity>>

    @Query("SELECT * FROM order_invoices WHERE id = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: Long): OrderInvoiceEntity?

    @Query("SELECT * FROM order_invoices WHERE businessId = :businessId ORDER BY id DESC LIMIT 1")
    suspend fun getLatestOrder(businessId: Long): OrderInvoiceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderInvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItemEntity>)

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getOrderItems(orderId: Long): List<OrderItemEntity>

    @Query("SELECT SUM(grandTotal) FROM order_invoices WHERE businessId = :businessId AND orderType = 'SALE'")
    fun getTotalSalesRevenue(businessId: Long): Flow<Double?>

    @Query("SELECT SUM(grandTotal) FROM order_invoices WHERE businessId = :businessId AND orderType = 'SALE' AND orderDateEpoch >= :startOfDayEpoch")
    fun getTodaySalesRevenue(businessId: Long, startOfDayEpoch: Long): Flow<Double?>

    @Query("SELECT COUNT(*) FROM order_invoices WHERE businessId = :businessId AND orderType = 'SALE'")
    fun getTotalSalesCount(businessId: Long): Flow<Int>
}
