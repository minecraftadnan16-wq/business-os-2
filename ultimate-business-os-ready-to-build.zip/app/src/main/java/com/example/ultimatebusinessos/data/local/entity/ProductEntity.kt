package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    foreignKeys = [
        ForeignKey(
            entity = BusinessProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["businessId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["businessId", "sku"]),
        Index(value = ["businessId", "barcode"])
    ]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val sku: String,
    val barcode: String = "",
    val name: String,
    val category: String = "General",
    val unit: String = "pcs",
    val costPrice: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val wholesalePrice: Double = 0.0,
    val currentStock: Double = 0.0,
    val reorderAlertLevel: Double = 5.0,
    val taxRatePercent: Double = 0.0,
    val isService: Boolean = false,

    // Specialized industry fields
    val batchNumber: String = "",
    val expiryDateEpoch: Long? = null,
    val serialNumber: String = "",
    val variantSizeColor: String = "",
    val karatPurity: String = "",
    val weightInGrams: Double = 0.0,
    val rawMaterialNotes: String = "",
    val updatedAtEpoch: Long = System.currentTimeMillis()
)
