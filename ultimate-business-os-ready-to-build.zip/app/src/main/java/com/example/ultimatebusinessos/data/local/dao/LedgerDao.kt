package com.example.ultimatebusinessos.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LedgerDao {
    @Query("SELECT * FROM financial_ledger WHERE businessId = :businessId ORDER BY transactionDateEpoch DESC")
    fun getLedgerEntriesForBusiness(businessId: Long): Flow<List<FinancialLedgerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: FinancialLedgerEntity): Long

    @Query("SELECT SUM(amount) FROM financial_ledger WHERE businessId = :businessId AND accountDebit = :accountName")
    suspend fun sumDebit(businessId: Long, accountName: String): Double?

    @Query("SELECT SUM(amount) FROM financial_ledger WHERE businessId = :businessId AND accountCredit = :accountName")
    suspend fun sumCredit(businessId: Long, accountName: String): Double?

    @Query("SELECT SUM(amount) FROM financial_ledger WHERE businessId = :businessId AND referenceType = 'EXPENSE'")
    fun getTotalExpenses(businessId: Long): Flow<Double?>

    @Query("UPDATE financial_ledger SET isReconciled = :reconciled WHERE id = :id")
    suspend fun setReconciliation(id: Long, reconciled: Boolean)

    @Query("SELECT * FROM financial_ledger WHERE businessId = :businessId AND (accountDebit = :accountName OR accountCredit = :accountName) ORDER BY transactionDateEpoch DESC")
    fun getEntriesByAccount(businessId: Long, accountName: String): Flow<List<FinancialLedgerEntity>>
}
