package com.example.ultimatebusinessos.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE businessId = :businessId ORDER BY name ASC")
    fun getProductsForBusiness(businessId: Long): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE businessId = :businessId AND (name LIKE '%' || :query || '%' OR sku LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%') ORDER BY name ASC")
    fun searchProducts(businessId: Long, query: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE businessId = :businessId AND currentStock <= reorderAlertLevel ORDER BY currentStock ASC")
    fun getLowStockProducts(businessId: Long): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Long): ProductEntity?

    @Query("SELECT * FROM products WHERE businessId = :businessId AND (barcode = :code OR sku = :code) LIMIT 1")
    suspend fun findByBarcodeOrSku(businessId: Long, code: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("UPDATE products SET currentStock = :newStock, updatedAtEpoch = :updatedAt WHERE id = :productId")
    suspend fun updateStock(productId: Long, newStock: Double, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE products SET currentStock = currentStock - :quantity, updatedAtEpoch = :updatedAt WHERE id = :productId")
    suspend fun deductStock(productId: Long, quantity: Double, updatedAt: Long = System.currentTimeMillis())

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("SELECT SUM(currentStock * costPrice) FROM products WHERE businessId = :businessId")
    fun getInventoryCostValuation(businessId: Long): Flow<Double?>

    @Query("SELECT SUM(currentStock * sellingPrice) FROM products WHERE businessId = :businessId")
    fun getInventoryRetailValuation(businessId: Long): Flow<Double?>

    @Query("SELECT COUNT(*) FROM products WHERE businessId = :businessId")
    suspend fun countProducts(businessId: Long): Int
}
