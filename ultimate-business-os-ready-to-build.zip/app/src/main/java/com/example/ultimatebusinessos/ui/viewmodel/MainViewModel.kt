package com.example.ultimatebusinessos.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ultimatebusinessos.data.local.AppDatabase
import com.example.ultimatebusinessos.data.local.entity.AuditLogEntity
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.EmployeeEntity
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import com.example.ultimatebusinessos.data.local.entity.OrderInvoiceEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.data.repository.BusinessRepository
import com.example.ultimatebusinessos.domain.model.BusinessCategory
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppOperatingMode(val title: String, val subtitle: String) {
    SIMPLE("Simple Mode", "Large buttons, plain language & direct actions for shopkeepers"),
    PROFESSIONAL("Professional Mode", "Double-entry ledger, trial balance, reconciliation & advanced ERP")
}

enum class AppScreen(val label: String, val group: String) {
    DASHBOARD("Dashboard", "Overview"),
    MY_BUSINESSES("My Businesses", "Entities"),
    SALES("Sales", "Operations"),
    PURCHASES("Purchases", "Operations"),
    PRODUCTS("Products", "Inventory"),
    INVENTORY("Inventory", "Inventory"),
    CUSTOMERS("Customers", "CRM"),
    SUPPLIERS("Suppliers", "CRM"),
    PAYMENTS("Payments", "Finance"),
    CASH_BANK("Cash and Bank", "Finance"),
    INCOME_EXPENSES("Income and Expenses", "Finance"),
    ACCOUNTING("Accounting", "Finance"),
    REMINDER_CENTER("Smart Reminder Center", "Intelligence"),
    REPORTS_ANALYTICS("Reports and Analytics", "Intelligence"),
    EMPLOYEES("Employees", "Team"),
    AI_ASSISTANT("AI Business Assistant", "Intelligence"),
    DOCUMENTS("Documents", "System"),
    SETTINGS("Settings", "System"),
    SYSTEM_ARCHITECTURE("Architecture Blueprint", "System")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BusinessRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = BusinessRepository(db)
        viewModelScope.launch {
            repository.initialize()
        }
    }

    private val _operatingMode = MutableStateFlow(AppOperatingMode.SIMPLE)
    val operatingMode: StateFlow<AppOperatingMode> = _operatingMode.asStateFlow()

    fun toggleOperatingMode() {
        _operatingMode.value = if (_operatingMode.value == AppOperatingMode.SIMPLE) {
            AppOperatingMode.PROFESSIONAL
        } else {
            AppOperatingMode.SIMPLE
        }
        viewModelScope.launch {
            _uiMessage.emit("Switched to ${_operatingMode.value.title}")
        }
    }

    private val _isReducedMotion = MutableStateFlow(false)
    val isReducedMotion: StateFlow<Boolean> = _isReducedMotion.asStateFlow()

    fun toggleReducedMotion() {
        _isReducedMotion.value = !_isReducedMotion.value
        viewModelScope.launch {
            _uiMessage.emit(if (_isReducedMotion.value) "Liquid Glass: Reduced Motion Enabled (Battery Saver)" else "Liquid Glass: Dynamic Atmospheric Lighting Enabled")
        }
    }

    fun setOperatingMode(mode: AppOperatingMode) {
        _operatingMode.value = mode
        viewModelScope.launch {
            _uiMessage.emit("Switched to ${mode.title}")
        }
    }

    private val _currentScreen = MutableStateFlow(AppScreen.DASHBOARD)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _uiMessage = MutableSharedFlow<String>()
    val uiMessage: SharedFlow<String> = _uiMessage.asSharedFlow()

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    val activeBusiness: StateFlow<BusinessProfileEntity?> = repository.activeBusiness
    val allBusinesses: StateFlow<List<BusinessProfileEntity>> = repository.allBusinesses.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val products: StateFlow<List<ProductEntity>> = repository.getProducts().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val lowStockProducts: StateFlow<List<ProductEntity>> = repository.getLowStockProducts().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val contacts: StateFlow<List<CustomerSupplierEntity>> = repository.getContacts().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val orders: StateFlow<List<OrderInvoiceEntity>> = repository.getOrders().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val salesOrders: StateFlow<List<OrderInvoiceEntity>> = orders.map { list ->
        list.filter { it.orderType == "SALE" }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchaseOrders: StateFlow<List<OrderInvoiceEntity>> = orders.map { list ->
        list.filter { it.orderType == "PURCHASE" }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ledgerEntries: StateFlow<List<FinancialLedgerEntity>> = repository.getLedgerEntries().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.getAuditLogs().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val employees: StateFlow<List<EmployeeEntity>> = repository.getEmployees().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Running balances for Cash and Bank calculated mathematically from ledger
    val cashOnHandBalance: StateFlow<Double> = ledgerEntries.map { entries ->
        val debits = entries.filter { it.accountDebit == "Cash On Hand" }.sumOf { it.amount }
        val credits = entries.filter { it.accountCredit == "Cash On Hand" }.sumOf { it.amount }
        debits - credits
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val bankAccountBalance: StateFlow<Double> = ledgerEntries.map { entries ->
        val debits = entries.filter { it.accountDebit == "Primary Bank Account" }.sumOf { it.amount }
        val credits = entries.filter { it.accountCredit == "Primary Bank Account" }.sumOf { it.amount }
        debits - credits
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val inventoryValuation: StateFlow<Double> = repository.getInventoryValuation()
        .combine(MutableStateFlow(0.0)) { cost, _ -> cost ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalRevenue: StateFlow<Double> = repository.getTotalSalesRevenue()
        .combine(MutableStateFlow(0.0)) { rev, _ -> rev ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpenses: StateFlow<Double> = repository.getTotalExpenses()
        .combine(MutableStateFlow(0.0)) { exp, _ -> exp ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalReceivables: StateFlow<Double> = repository.getTotalReceivables()
        .combine(MutableStateFlow(0.0)) { rec, _ -> rec ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalPayables: StateFlow<Double> = repository.getTotalPayables()
        .combine(MutableStateFlow(0.0)) { pay, _ -> pay ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // POS Cart State
    private val _cart = MutableStateFlow<List<BusinessRepository.CartItem>>(emptyList())
    val cart: StateFlow<List<BusinessRepository.CartItem>> = _cart.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<CustomerSupplierEntity?>(null)
    val selectedCustomer: StateFlow<CustomerSupplierEntity?> = _selectedCustomer.asStateFlow()

    private val _paymentMethod = MutableStateFlow("CASH")
    val paymentMethod: StateFlow<String> = _paymentMethod.asStateFlow()

    private val _orderNotes = MutableStateFlow("")
    val orderNotes: StateFlow<String> = _orderNotes.asStateFlow()

    fun addToCart(product: ProductEntity) {
        val current = _cart.value.toMutableList()
        val existingIndex = current.indexOfFirst { it.product.id == product.id }
        if (existingIndex >= 0) {
            val item = current[existingIndex]
            current[existingIndex] = item.copy(quantity = item.quantity + 1.0)
        } else {
            current.add(
                BusinessRepository.CartItem(
                    product = product,
                    quantity = 1.0,
                    unitPrice = product.sellingPrice,
                    discountPercent = 0.0
                )
            )
        }
        _cart.value = current
    }

    fun updateCartQuantity(productId: Long, delta: Double) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            val item = current[index]
            val newQty = item.quantity + delta
            if (newQty <= 0.0) {
                current.removeAt(index)
            } else {
                current[index] = item.copy(quantity = newQty)
            }
            _cart.value = current
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _orderNotes.value = ""
        _selectedCustomer.value = null
    }

    fun setSelectedCustomer(customer: CustomerSupplierEntity?) {
        _selectedCustomer.value = customer
    }

    fun setPaymentMethod(method: String) {
        _paymentMethod.value = method
    }

    fun setOrderNotes(notes: String) {
        _orderNotes.value = notes
    }

    fun checkoutCurrentCart(amountPaid: Double) {
        viewModelScope.launch {
            val result = repository.checkoutSale(
                cartItems = _cart.value,
                customer = _selectedCustomer.value,
                paymentMethod = _paymentMethod.value,
                amountPaid = amountPaid,
                orderNotes = _orderNotes.value
            )
            if (result.isSuccess) {
                clearCart()
                _uiMessage.emit("Sale recorded! Receipt generated with cryptographic audit seal.")
                _currentScreen.value = AppScreen.DASHBOARD
            } else {
                _uiMessage.emit("Error recording sale: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    fun recordPurchaseBill(
        supplier: CustomerSupplierEntity?,
        items: List<BusinessRepository.CartItem>,
        paymentMethod: String,
        amountPaid: Double,
        notes: String
    ) {
        viewModelScope.launch {
            val result = repository.recordPurchaseBill(
                supplier = supplier,
                items = items,
                paymentMethod = paymentMethod,
                amountPaid = amountPaid,
                notes = notes
            )
            if (result.isSuccess) {
                _uiMessage.emit("Purchase recorded and stock replenished!")
                _currentScreen.value = AppScreen.PURCHASES
            } else {
                _uiMessage.emit("Purchase error: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    fun receiveCustomerPayment(
        customer: CustomerSupplierEntity,
        amount: Double,
        destinationAccount: String,
        notes: String
    ) {
        viewModelScope.launch {
            val result = repository.receiveCustomerPayment(
                customer = customer,
                amount = amount,
                destinationAccount = destinationAccount,
                notes = notes
            )
            if (result.isSuccess) {
                _uiMessage.emit("Received $amount from ${customer.name}. Account balance updated!")
            } else {
                _uiMessage.emit("Payment failed: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    fun paySupplierBill(
        supplier: CustomerSupplierEntity,
        amount: Double,
        sourceAccount: String,
        notes: String
    ) {
        viewModelScope.launch {
            val result = repository.paySupplierBill(
                supplier = supplier,
                amount = amount,
                sourceAccount = sourceAccount,
                notes = notes
            )
            if (result.isSuccess) {
                _uiMessage.emit("Paid $amount to ${supplier.name}. Vendor payable updated!")
            } else {
                _uiMessage.emit("Disbursement failed: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    fun recordJournalEntry(
        debitAccount: String,
        creditAccount: String,
        amount: Double,
        description: String
    ) {
        viewModelScope.launch {
            val result = repository.recordJournalEntry(
                debitAccount = debitAccount,
                creditAccount = creditAccount,
                amount = amount,
                description = description
            )
            if (result.isSuccess) {
                _uiMessage.emit("Balanced Journal Voucher posted to General Ledger!")
            } else {
                _uiMessage.emit("Journal Voucher error: ${result.exceptionOrNull()?.message}")
            }
        }
    }

    fun toggleLedgerReconciliation(ledgerId: Long, currentReconciled: Boolean) {
        viewModelScope.launch {
            repository.toggleLedgerReconciliation(ledgerId, !currentReconciled)
            _uiMessage.emit("Reconciliation status toggled.")
        }
    }

    fun switchBusiness(businessId: Long) {
        viewModelScope.launch {
            repository.switchBusiness(businessId)
            clearCart()
            _uiMessage.emit("Active business context switched.")
            _currentScreen.value = AppScreen.DASHBOARD
        }
    }

    fun createBusiness(
        name: String,
        tagline: String,
        category: BusinessCategory,
        currencySymbol: String,
        currencyCode: String,
        taxRate: Double,
        taxNumber: String,
        phone: String,
        email: String,
        address: String
    ) {
        viewModelScope.launch {
            val id = repository.createNewBusiness(
                name = name,
                tagline = tagline,
                category = category,
                currencySymbol = currencySymbol,
                currencyCode = currencyCode,
                taxRate = taxRate,
                taxNumber = taxNumber,
                phone = phone,
                email = email,
                address = address,
                activeModules = category.recommendedModules
            )
            _uiMessage.emit("Created new business '${name.ifBlank { category.title }}'!")
            _currentScreen.value = AppScreen.DASHBOARD
        }
    }

    fun addProduct(
        name: String,
        sku: String,
        barcode: String,
        category: String,
        unit: String,
        costPrice: Double,
        sellingPrice: Double,
        wholesalePrice: Double,
        stock: Double,
        reorderLevel: Double,
        taxRate: Double,
        batchNumber: String,
        serialNumber: String,
        variant: String
    ) {
        viewModelScope.launch {
            val bizId = activeBusiness.value?.id ?: 1L
            repository.addProduct(
                ProductEntity(
                    businessId = bizId,
                    name = name,
                    sku = sku.ifBlank { "SKU-${System.currentTimeMillis() % 100000}" },
                    barcode = barcode,
                    category = category.ifBlank { "General" },
                    unit = unit.ifBlank { "pcs" },
                    costPrice = costPrice,
                    sellingPrice = sellingPrice,
                    wholesalePrice = wholesalePrice,
                    currentStock = stock,
                    reorderAlertLevel = reorderLevel,
                    taxRatePercent = taxRate,
                    batchNumber = batchNumber,
                    serialNumber = serialNumber,
                    variantSizeColor = variant
                )
            )
            _uiMessage.emit("Product '$name' added to catalog.")
        }
    }

    fun adjustStock(productId: Long, newStock: Double, reason: String) {
        viewModelScope.launch {
            repository.adjustStock(productId, newStock, reason)
            _uiMessage.emit("Stock adjusted with audit trail.")
        }
    }

    fun addContact(
        name: String,
        type: String,
        phone: String,
        email: String,
        address: String,
        creditLimit: Double
    ) {
        viewModelScope.launch {
            val bizId = activeBusiness.value?.id ?: 1L
            repository.addContact(
                CustomerSupplierEntity(
                    businessId = bizId,
                    type = type,
                    name = name,
                    phone = phone,
                    email = email,
                    address = address,
                    creditLimit = creditLimit
                )
            )
            _uiMessage.emit("$type '$name' added.")
        }
    }

    fun addEmployee(
        name: String,
        role: String,
        phone: String,
        email: String,
        salary: Double,
        pin: String
    ) {
        viewModelScope.launch {
            val result = repository.addEmployee(name, role, phone, email, salary, pin)
            if (result.isSuccess) {
                _uiMessage.emit("Employee '$name' added.")
            } else {
                _uiMessage.emit("Failed to add employee.")
            }
        }
    }

    fun deleteEmployee(employee: EmployeeEntity) {
        viewModelScope.launch {
            repository.deleteEmployee(employee)
            _uiMessage.emit("Employee '${employee.name}' removed.")
        }
    }

    fun recordExpense(title: String, amount: Double, category: String) {
        viewModelScope.launch {
            val result = repository.recordExpense(title, amount, category, "Cash On Hand")
            if (result.isSuccess) {
                _uiMessage.emit("Expense logged and recorded in financial ledger.")
            } else {
                _uiMessage.emit("Failed to log expense.")
            }
        }
    }
}
