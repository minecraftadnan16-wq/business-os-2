package com.example.ultimatebusinessos.ui.theme

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlassBackgroundDark
import com.example.ui.theme.GlassBackgroundLight
import com.example.ui.theme.GlassBorderCyanEnd
import com.example.ui.theme.GlassBorderCyanStart
import com.example.ui.theme.GlassBorderGradientEnd
import com.example.ui.theme.GlassBorderGradientStart
import com.example.ui.theme.GlassWhiteHigh
import com.example.ui.theme.GlassWhiteLow
import com.example.ui.theme.GlassWhiteMedium
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidViolet

object LiquidGlassDefaults {
    val DefaultCardShape = RoundedCornerShape(20.dp)
    val LargePanelShape = RoundedCornerShape(24.dp)
    val SmallPillShape = RoundedCornerShape(12.dp)
}

/**
 * Renders an ambient cosmic background with animated soft glowing auroras
 * and multi-layered atmospheric illumination.
 */
@Composable
fun Modifier.liquidGlassBackground(
    isDark: Boolean = isSystemInDarkTheme(),
    isReducedMotion: Boolean = false
): Modifier {
    val infiniteTransition = rememberInfiniteTransition(label = "liquid_aurora")
    val pulse by if (!isReducedMotion) {
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 8000, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse_anim"
        )
    } else {
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(0.5f) }
    }

    return this.drawBehind {
        val width = size.width
        val height = size.height

        if (isDark) {
            // Dark Void Base
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF040711),
                        Color(0xFF080E20),
                        Color(0xFF050917)
                    )
                )
            )

            // Aurora 1: Electric Cyan Glow (Top Right)
            val cyanRadius = width * (0.65f + 0.15f * pulse)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidCyan.copy(alpha = 0.18f + 0.05f * pulse),
                        LiquidCyan.copy(alpha = 0.06f),
                        Color.Transparent
                    ),
                    center = Offset(width * (0.85f - 0.05f * pulse), height * 0.15f),
                    radius = cyanRadius
                ),
                center = Offset(width * 0.85f, height * 0.15f),
                radius = cyanRadius
            )

            // Aurora 2: Cosmic Violet Glow (Bottom Left)
            val violetRadius = width * (0.75f + 0.12f * (1f - pulse))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidViolet.copy(alpha = 0.16f + 0.04f * (1f - pulse)),
                        LiquidViolet.copy(alpha = 0.04f),
                        Color.Transparent
                    ),
                    center = Offset(width * 0.15f, height * 0.75f),
                    radius = violetRadius
                ),
                center = Offset(width * 0.15f, height * 0.75f),
                radius = violetRadius
            )

            // Aurora 3: Subtle Emerald Aurora (Center)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        LiquidEmerald.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = Offset(width * 0.5f, height * 0.45f),
                    radius = width * 0.55f
                ),
                center = Offset(width * 0.5f, height * 0.45f),
                radius = width * 0.55f
            )
        } else {
            // Light Ice Glass Base
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFF8FAFC),
                        Color(0xFFEFF6FF),
                        Color(0xFFF1F5F9)
                    )
                )
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFBAE6FD).copy(alpha = 0.35f),
                        Color.Transparent
                    ),
                    center = Offset(width * 0.85f, height * 0.12f),
                    radius = width * 0.7f
                )
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFDDD6FE).copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = Offset(width * 0.15f, height * 0.85f),
                    radius = width * 0.75f
                )
            )
        }
    }
}

/**
 * Premium Frosted Glass Card with subtle specular highlight,
 * translucent layered surface, and refraction border.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = LiquidGlassDefaults.DefaultCardShape,
    borderBrush: Brush? = null,
    glowColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()

    val surfaceColor = if (isDark) {
        Color(0x1F1E293B) // 12% opacity slate glass
    } else {
        Color(0xD9FFFFFF) // 85% opacity crystal ice
    }

    val finalBorderBrush = borderBrush ?: Brush.linearGradient(
        colors = if (isDark) {
            listOf(
                GlassBorderGradientStart,
                GlassBorderGradientEnd,
                Color(0x05FFFFFF),
                GlassBorderGradientStart.copy(alpha = 0.25f)
            )
        } else {
            listOf(
                Color(0x80FFFFFF),
                Color(0x33CBD5E1),
                Color(0x10FFFFFF)
            )
        }
    )

    Box(
        modifier = modifier
            .then(
                if (glowColor != null) {
                    Modifier.drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(glowColor.copy(alpha = 0.18f), Color.Transparent),
                                radius = size.maxDimension * 0.6f
                            )
                        )
                    }
                } else Modifier
            )
            .clip(shape)
            .background(surfaceColor)
            .drawBehind {
                // Specular top highlight / inner refraction glow
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            if (isDark) Color(0x22FFFFFF) else Color(0x66FFFFFF),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = size.height * 0.35f
                    )
                )
            }
            .border(
                width = 1.dp,
                brush = finalBorderBrush,
                shape = shape
            )
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        content = content
    )
}

/**
 * Floating Navigation Glass Dock with high translucency,
 * glowing rim reflection and blur-like appearance.
 */
@Composable
fun GlassFloatingDock(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val dockBg = if (isDark) Color(0xDD0B1226) else Color(0xF2FFFFFF)
    val dockBorder = if (isDark) {
        Brush.linearGradient(
            listOf(
                GlassBorderCyanStart,
                GlassBorderGradientEnd,
                GlassBorderCyanEnd
            )
        )
    } else {
        Brush.linearGradient(
            listOf(
                Color(0xCC38BDF8),
                Color(0x40CBD5E1)
            )
        )
    }

    Box(
        modifier = modifier
            .drawBehind {
                // Subtle ambient glow beneath the floating dock
                drawRoundRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            LiquidCyan.copy(alpha = 0.15f),
                            Color.Transparent
                        ),
                        radius = size.width * 0.6f
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(60f, 60f)
                )
            }
            .clip(shape)
            .background(dockBg)
            .border(width = 1.5.dp, brush = dockBorder, shape = shape),
        content = content
    )
}
