package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.ui.theme.GlassCard
import com.example.ultimatebusinessos.ui.viewmodel.AppOperatingMode
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen

@Composable
fun SettingsScreen(
    business: BusinessProfileEntity?,
    operatingMode: AppOperatingMode,
    onSetMode: (AppOperatingMode) -> Unit,
    isReducedMotion: Boolean = false,
    onToggleReducedMotion: () -> Unit = {},
    productCount: Int,
    orderCount: Int,
    ledgerCount: Int,
    onNavigate: (AppScreen) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "System Settings & Configuration",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Operating mode, business profile & preferences",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Operating Experience Mode Switcher (Simple vs Professional)
            item {
                Text("Operating Experience Mode", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Switch between the streamlined shopkeeper interface and the enterprise double-entry accounting suite at any time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Simple Mode Card Option
                val isSimple = operatingMode == AppOperatingMode.SIMPLE
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSetMode(AppOperatingMode.SIMPLE) }
                        .testTag("setting_mode_simple"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSimple) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isSimple) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                            contentDescription = null,
                            tint = if (isSimple) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Simple Mode (Shopkeeper Friendly)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Easy language, large touch buttons, quick sales, debt collection, quick expense logging, and plain-language summaries.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Professional Mode Card Option
                val isPro = operatingMode == AppOperatingMode.PROFESSIONAL
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSetMode(AppOperatingMode.PROFESSIONAL) }
                        .testTag("setting_mode_professional"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPro) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isPro) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                            contentDescription = null,
                            tint = if (isPro) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Professional Mode (Enterprise & Accountant)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Double-entry General Ledger, balanced Journal Vouchers (Dr/Cr), real-time Trial Balance verification, bank reconciliation, and advanced inventory costing.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Liquid Glass Visual Engine & Adaptive Rendering
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Liquid Glass Visual Engine", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Control translucent glass refraction, dynamic atmospheric auroras, and GPU shader performance.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isReducedMotion) Icons.Default.Speed else Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = if (isReducedMotion) MaterialTheme.colorScheme.primary else Color(0xFF00E5FF)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isReducedMotion) "Battery Saver Mode (Reduced Motion)" else "Dynamic Atmospheric Illumination",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = if (isReducedMotion) "Static glass frosted surfaces; animation loop paused for battery longevity." else "Animated cosmic aurora pulsing, specular refraction highlights, and ambient glow.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = !isReducedMotion,
                                onCheckedChange = { onToggleReducedMotion() },
                                modifier = Modifier.testTag("btn_toggle_reduced_motion")
                            )
                        }
                    }
                }
            }

            // Current Business Identity Card
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Active Business Identity", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(business?.businessName ?: "Ultimate Business OS", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("Industry Category: ${business?.category}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                            Button(
                                onClick = { onNavigate(AppScreen.MY_BUSINESSES) },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Switch / Add", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("• Currency: ${business?.currencySymbol} (${business?.currencyCode})", style = MaterialTheme.typography.bodySmall)
                        Text("• Default Tax Rate: ${business?.defaultTaxRate}%", style = MaterialTheme.typography.bodySmall)
                        Text("• Tax ID / Registration: ${business?.taxNumber.orEmpty().ifBlank { "Not configured" }}", style = MaterialTheme.typography.bodySmall)
                        Text("• Address: ${business?.address.orEmpty().ifBlank { "Not configured" }}", style = MaterialTheme.typography.bodySmall)
                        Text("• Phone: ${business?.phone.orEmpty().ifBlank { "Not configured" }}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Local Database Health & Architecture
            item {
                Text("Offline Storage Engine & Health", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedCard(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Embedded SQLite Database", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("• Active Catalog Items: $productCount", style = MaterialTheme.typography.bodySmall)
                        Text("• Invoices & Bills: $orderCount", style = MaterialTheme.typography.bodySmall)
                        Text("• Double-Entry Ledger Lines: $ledgerCount", style = MaterialTheme.typography.bodySmall)
                        Text("• Architecture: Offline-first with ACID write-ahead logging (WAL)", style = MaterialTheme.typography.bodySmall)

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { onNavigate(AppScreen.SYSTEM_ARCHITECTURE) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Open System Architecture Blueprint")
                        }
                    }
                }
            }
        }
    }
}
