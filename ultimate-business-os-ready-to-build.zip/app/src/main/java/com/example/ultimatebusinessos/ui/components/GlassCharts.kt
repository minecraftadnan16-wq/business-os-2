package com.example.ultimatebusinessos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LiquidAmber
import com.example.ui.theme.LiquidCyan
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidViolet
import com.example.ultimatebusinessos.ui.theme.GlassCard

/**
 * Premium Liquid Wave Financial Chart rendering real revenue and profit
 * curves with luminous gradient area under-glows.
 */
@Composable
fun LiquidFinancialWaveChart(
    revenuePoints: List<Double>,
    profitPoints: List<Double>,
    labels: List<String>,
    currencySymbol: String = "$",
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        glowColor = LiquidCyan
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Cashflow & Profit Trajectory",
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Real-time ledger transaction stream",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ChartLegendItem(color = LiquidCyan, label = "Revenue")
                    ChartLegendItem(color = LiquidEmerald, label = "Net Profit")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val revList = if (revenuePoints.isEmpty()) listOf(0.0, 450.0, 920.0, 1400.0, 1850.0, 2400.0) else revenuePoints
            val profList = if (profitPoints.isEmpty()) listOf(0.0, 180.0, 390.0, 620.0, 890.0, 1250.0) else profitPoints
            val maxVal = (revList + profList).maxOrNull()?.coerceAtLeast(100.0) ?: 100.0

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                val w = size.width
                val h = size.height
                val stepX = w / (revList.size - 1).coerceAtLeast(1)

                // Horizontal Guide Lines
                for (i in 1..3) {
                    val y = h * (i / 4f)
                    drawLine(
                        color = Color(0x1AFFFFFF),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                // Function to build smooth cubic curve path
                fun buildPath(points: List<Double>): Pair<Path, Path> {
                    val linePath = Path()
                    val areaPath = Path()

                    points.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val normalizedY = (1f - (pt / maxVal).toFloat()).coerceIn(0.05f, 0.95f)
                        val y = normalizedY * h

                        if (i == 0) {
                            linePath.moveTo(x, y)
                            areaPath.moveTo(x, h)
                            areaPath.lineTo(x, y)
                        } else {
                            val prevX = (i - 1) * stepX
                            val prevY = (1f - (points[i - 1] / maxVal).toFloat()).coerceIn(0.05f, 0.95f) * h
                            val controlX1 = prevX + (x - prevX) / 2
                            val controlY1 = prevY
                            val controlX2 = prevX + (x - prevX) / 2
                            val controlY2 = y

                            linePath.cubicTo(controlX1, controlY1, controlX2, controlY2, x, y)
                            areaPath.cubicTo(controlX1, controlY1, controlX2, controlY2, x, y)
                        }
                    }
                    areaPath.lineTo(w, h)
                    areaPath.close()
                    return Pair(linePath, areaPath)
                }

                // 1. Draw Revenue Area & Line
                val (revLine, revArea) = buildPath(revList)
                drawPath(
                    path = revArea,
                    brush = Brush.verticalGradient(
                        colors = listOf(LiquidCyan.copy(alpha = 0.28f), Color.Transparent),
                        startY = 0f,
                        endY = h
                    )
                )
                drawPath(
                    path = revLine,
                    brush = Brush.horizontalGradient(
                        listOf(LiquidCyan.copy(alpha = 0.8f), LiquidCyan, Color(0xFF67E8F9))
                    ),
                    style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // 2. Draw Net Profit Area & Line
                val (profLine, profArea) = buildPath(profList)
                drawPath(
                    path = profArea,
                    brush = Brush.verticalGradient(
                        colors = listOf(LiquidEmerald.copy(alpha = 0.25f), Color.Transparent),
                        startY = 0f,
                        endY = h
                    )
                )
                drawPath(
                    path = profLine,
                    brush = Brush.horizontalGradient(
                        listOf(LiquidEmerald.copy(alpha = 0.8f), LiquidEmerald, Color(0xFF6EE7B7))
                    ),
                    style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                )

                // Draw glowing node point at the end of each line
                val lastRevX = (revList.size - 1) * stepX
                val lastRevY = (1f - (revList.last() / maxVal).toFloat()).coerceIn(0.05f, 0.95f) * h
                drawCircle(color = LiquidCyan, radius = 6.dp.toPx(), center = Offset(lastRevX, lastRevY))
                drawCircle(color = Color.White, radius = 2.5.dp.toPx(), center = Offset(lastRevX, lastRevY))

                val lastProfX = (profList.size - 1) * stepX
                val lastProfY = (1f - (profList.last() / maxVal).toFloat()).coerceIn(0.05f, 0.95f) * h
                drawCircle(color = LiquidEmerald, radius = 6.dp.toPx(), center = Offset(lastProfX, lastProfY))
                drawCircle(color = Color.White, radius = 2.5.dp.toPx(), center = Offset(lastProfX, lastProfY))
            }

            // X-Axis Labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val axisLabels = if (labels.isEmpty()) listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Today") else labels
                axisLabels.forEach { label ->
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * Luminous Liquid Asset Allocation Donut Ring Chart.
 */
@Composable
fun LiquidAssetDonutChart(
    cashAmount: Double,
    bankAmount: Double,
    inventoryAmount: Double,
    receivablesAmount: Double,
    currencySymbol: String = "$",
    modifier: Modifier = Modifier
) {
    val totalAssets = (cashAmount + bankAmount + inventoryAmount + receivablesAmount).coerceAtLeast(1.0)
    val cashPercent = (cashAmount / totalAssets) * 100
    val bankPercent = (bankAmount / totalAssets) * 100
    val invPercent = (inventoryAmount / totalAssets) * 100
    val recPercent = (receivablesAmount / totalAssets) * 100

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        glowColor = LiquidViolet
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Liquid Asset Allocation",
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "Balance Sheet Liquidity Breakdown",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Donut Canvas
                Box(
                    modifier = Modifier.size(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(130.dp)) {
                        val strokeW = 18.dp.toPx()
                        val padding = strokeW / 2
                        val arcSize = Size(size.width - strokeW, size.height - strokeW)
                        val arcOffset = Offset(padding, padding)

                        var startAngle = -90f

                        val segments = listOf(
                            Pair(cashAmount, LiquidEmerald),
                            Pair(bankAmount, LiquidCyan),
                            Pair(inventoryAmount, LiquidViolet),
                            Pair(receivablesAmount, LiquidAmber)
                        )

                        segments.forEach { (amt, color) ->
                            val sweep = ((amt / totalAssets).toFloat() * 360f).coerceAtLeast(1f)
                            drawArc(
                                color = color,
                                startAngle = startAngle,
                                sweepAngle = sweep - 2f, // subtle gap
                                useCenter = false,
                                topLeft = arcOffset,
                                size = arcSize,
                                style = Stroke(width = strokeW, cap = StrokeCap.Round)
                            )
                            startAngle += sweep
                        }
                    }

                    // Glass Hub Center
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Net Value",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = "$currencySymbol${"%.0f".format(totalAssets)}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Asset breakdown list
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssetItemRow(color = LiquidEmerald, name = "Cash In Drawer", amount = "$currencySymbol${"%.2f".format(cashAmount)}", percent = "${"%.0f".format(cashPercent)}%")
                    AssetItemRow(color = LiquidCyan, name = "Bank Account", amount = "$currencySymbol${"%.2f".format(bankAmount)}", percent = "${"%.0f".format(bankPercent)}%")
                    AssetItemRow(color = LiquidViolet, name = "Stock Asset", amount = "$currencySymbol${"%.2f".format(inventoryAmount)}", percent = "${"%.0f".format(invPercent)}%")
                    AssetItemRow(color = LiquidAmber, name = "Customer Due", amount = "$currencySymbol${"%.2f".format(receivablesAmount)}", percent = "${"%.0f".format(recPercent)}%")
                }
            }
        }
    }
}

@Composable
fun AssetItemRow(
    color: Color,
    name: String,
    amount: String,
    percent: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(amount, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
            }
        }
        Text(percent, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun ChartLegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
