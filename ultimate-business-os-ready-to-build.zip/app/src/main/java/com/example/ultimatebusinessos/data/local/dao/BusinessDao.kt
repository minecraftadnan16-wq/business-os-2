package com.example.ultimatebusinessos.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BusinessDao {
    @Query("SELECT * FROM business_profiles ORDER BY isPrimary DESC, createdAtEpoch ASC")
    fun getAllBusinesses(): Flow<List<BusinessProfileEntity>>

    @Query("SELECT * FROM business_profiles WHERE id = :id LIMIT 1")
    suspend fun getBusinessById(id: Long): BusinessProfileEntity?

    @Query("SELECT * FROM business_profiles WHERE isPrimary = 1 LIMIT 1")
    suspend fun getPrimaryBusiness(): BusinessProfileEntity?

    @Query("SELECT * FROM business_profiles ORDER BY id ASC LIMIT 1")
    suspend fun getFirstBusiness(): BusinessProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBusiness(business: BusinessProfileEntity): Long

    @Update
    suspend fun updateBusiness(business: BusinessProfileEntity)

    @Query("UPDATE business_profiles SET isPrimary = 0")
    suspend fun clearPrimaryFlag()

    @Query("UPDATE business_profiles SET isPrimary = 1 WHERE id = :id")
    suspend fun setPrimary(id: Long)

    @Query("SELECT COUNT(*) FROM business_profiles")
    suspend fun countBusinesses(): Int
}
