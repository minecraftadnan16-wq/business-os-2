package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "order_invoices",
    foreignKeys = [
        ForeignKey(
            entity = BusinessProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["businessId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["businessId", "invoiceNumber"], unique = true),
        Index(value = ["businessId", "orderDateEpoch"]),
        Index(value = ["customerSupplierId"])
    ]
)
data class OrderInvoiceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val invoiceNumber: String,
    val orderType: String = "SALE", // "SALE", "PURCHASE", "RETURN_SALE", "QUOTATION"
    val customerSupplierId: Long? = null,
    val customerSupplierName: String = "Walk-in Customer",
    val orderDateEpoch: Long = System.currentTimeMillis(),
    val subtotal: Double = 0.0,
    val discountAmount: Double = 0.0,
    val taxAmount: Double = 0.0,
    val grandTotal: Double = 0.0,
    val paidAmount: Double = 0.0,
    val balanceDue: Double = 0.0,
    val paymentMethod: String = "CASH", // "CASH", "CARD", "MOBILE_MONEY", "CREDIT_LEDGER", "BANK"
    val paymentStatus: String = "PAID", // "PAID", "PARTIAL", "UNPAID"
    val fulfillmentStatus: String = "COMPLETED", // "COMPLETED", "PENDING", "PREPARING", "CANCELLED"
    val notes: String = "",
    val receiptHash: String = "", // Cryptographic verification seal
    val cashierName: String = "Staff"
)
