package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "employees",
    foreignKeys = [
        ForeignKey(
            entity = BusinessProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["businessId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["businessId", "role"])
    ]
)
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val name: String,
    val role: String, // "OWNER", "MANAGER", "CASHIER", "AUDITOR", "STOCK_CLERK"
    val phone: String = "",
    val email: String = "",
    val salary: Double = 0.0,
    val pinCode: String = "1234",
    val status: String = "ACTIVE", // "ACTIVE", "ON_LEAVE", "INACTIVE"
    val joinedDateEpoch: Long = System.currentTimeMillis()
)
