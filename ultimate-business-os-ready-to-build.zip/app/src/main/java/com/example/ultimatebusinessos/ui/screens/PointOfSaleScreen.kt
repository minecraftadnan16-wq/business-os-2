package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.data.repository.BusinessRepository
import com.example.ultimatebusinessos.domain.calculation.FinancialCalculator
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PointOfSaleScreen(
    business: BusinessProfileEntity?,
    products: List<ProductEntity>,
    contacts: List<CustomerSupplierEntity>,
    cart: List<BusinessRepository.CartItem>,
    selectedCustomer: CustomerSupplierEntity?,
    paymentMethod: String,
    onAddToCart: (ProductEntity) -> Unit,
    onUpdateQuantity: (Long, Double) -> Unit,
    onClearCart: () -> Unit,
    onSelectCustomer: (CustomerSupplierEntity?) -> Unit,
    onSelectPaymentMethod: (String) -> Unit,
    onCheckout: (Double) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = business?.currencySymbol ?: "$"
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var tenderInput by remember { mutableStateOf("") }

    // Categories filter
    val categories = remember(products) {
        listOf("All") + products.map { it.category }.distinct()
    }

    val filteredProducts = remember(products, searchQuery, selectedCategory) {
        products.filter { prod ->
            val matchesCategory = selectedCategory == "All" || prod.category.equals(selectedCategory, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                prod.name.contains(searchQuery, ignoreCase = true) ||
                prod.sku.contains(searchQuery, ignoreCase = true) ||
                prod.barcode.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    // Mathematical calculations for current cart
    val lineCalculations = remember(cart) {
        cart.map { item ->
            FinancialCalculator.calculateLineItem(
                quantity = item.quantity,
                unitPrice = item.unitPrice,
                costPrice = item.product.costPrice,
                discountPercent = item.discountPercent,
                taxRatePercent = item.product.taxRatePercent
            )
        }
    }

    val invoiceTotals = remember(lineCalculations) {
        FinancialCalculator.calculateInvoice(lines = lineCalculations)
    }

    val tenderAmount = tenderInput.toDoubleOrNull() ?: invoiceTotals.grandTotal
    val changeDue = remember(tenderAmount, invoiceTotals.grandTotal) {
        FinancialCalculator.round((tenderAmount - invoiceTotals.grandTotal).coerceAtLeast(0.0))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("pos_screen")
    ) {
        // POS Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Point of Sale (Terminal 01)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = business?.businessName ?: "Ultimate Business OS",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (cart.isNotEmpty()) {
                OutlinedButton(onClick = onClearCart) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear Cart")
                }
            }
        }

        HorizontalDivider()

        // Content split or stack
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Search & Category row
            item {
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pos_search_input"),
                    placeholder = { Text("Search by name, SKU, barcode...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) }
                        )
                    }
                }
            }

            // Products Catalog section (Click to add)
            item {
                Text(
                    text = "Catalog (${filteredProducts.size} items)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            items(filteredProducts) { product ->
                PosProductCard(
                    product = product,
                    currency = currency,
                    onAdd = { onAddToCart(product) }
                )
            }

            // Cart Summary & Checkout Panel
            if (cart.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pos_cart_summary_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingCart,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Current Order (${cart.sumOf { it.quantity.toInt() }} items)",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Cart items list
                            cart.forEach { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.product.name,
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.bodyMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "$currency${"%.2f".format(item.unitPrice)} each",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = { onUpdateQuantity(item.product.id, -1.0) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                        }
                                        Text(
                                            text = " ${"%.0f".format(item.quantity)} ",
                                            fontWeight = FontWeight.Bold
                                        )
                                        IconButton(
                                            onClick = { onUpdateQuantity(item.product.id, 1.0) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "$currency${"%.2f".format(item.quantity * item.unitPrice)}",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Customer selection
                            Text(text = "Customer Account", style = MaterialTheme.typography.labelMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item {
                                    FilterChip(
                                        selected = selectedCustomer == null,
                                        onClick = { onSelectCustomer(null) },
                                        label = { Text("Walk-in Customer") }
                                    )
                                }
                                items(contacts.filter { it.type != "SUPPLIER" }) { cust ->
                                    FilterChip(
                                        selected = selectedCustomer?.id == cust.id,
                                        onClick = { onSelectCustomer(cust) },
                                        label = { Text(cust.name) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Payment method chips
                            Text(text = "Payment Method", style = MaterialTheme.typography.labelMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            val methods = listOf("CASH", "CARD", "MOBILE_MONEY", "CREDIT_LEDGER")
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                methods.forEach { method ->
                                    FilterChip(
                                        selected = paymentMethod == method,
                                        onClick = { onSelectPaymentMethod(method) },
                                        label = { Text(method.replace("_", " "), fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            // Tender cash input for cash payments
                            if (paymentMethod == "CASH") {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = tenderInput,
                                        onValueChange = { tenderInput = it },
                                        label = { Text("Cash Tendered") },
                                        placeholder = { Text("${invoiceTotals.grandTotal}") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("cash_tender_input"),
                                        singleLine = true
                                    )
                                    Column {
                                        Text(
                                            text = "Change Due",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "$currency${"%.2f".format(changeDue)}",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = Color(0xFF0D9488)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Invoice Calculations breakdown
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Subtotal:", style = MaterialTheme.typography.bodySmall)
                                Text("$currency${"%.2f".format(invoiceTotals.subtotal)}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (invoiceTotals.totalTax > 0.0) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Tax Rate Applied:", style = MaterialTheme.typography.bodySmall)
                                    Text("$currency${"%.2f".format(invoiceTotals.totalTax)}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Grand Total:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "$currency${"%.2f".format(invoiceTotals.grandTotal)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            val payAmount = if (paymentMethod == "CREDIT_LEDGER") 0.0 else tenderAmount.coerceAtMost(invoiceTotals.grandTotal)
                            Button(
                                onClick = { onCheckout(payAmount) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("checkout_button")
                            ) {
                                Text(
                                    text = "Complete Sale ($currency${"%.2f".format(invoiceTotals.grandTotal)})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun PosProductCard(
    product: ProductEntity,
    currency: String,
    onAdd: () -> Unit
) {
    OutlinedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onAdd)
            .testTag("pos_product_${product.id}"),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "SKU: ${product.sku} • Stock: ${"%.0f".format(product.currentStock)} ${product.unit}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (product.currentStock <= product.reorderAlertLevel) Color(0xFFDC2626) else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (product.batchNumber.isNotBlank() || product.serialNumber.isNotBlank() || product.variantSizeColor.isNotBlank()) {
                    Text(
                        text = "Spec: ${listOf(product.batchNumber, product.serialNumber, product.variantSizeColor).filter { it.isNotBlank() }.joinToString(" • ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$currency${"%.2f".format(product.sellingPrice)}",
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Button(
                    onClick = onAdd,
                    modifier = Modifier.height(36.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                    Text("Add", fontSize = 12.sp)
                }
            }
        }
    }
}
