package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "business_profiles",
    indices = [
        Index(value = ["businessName"], unique = false),
        Index(value = ["isPrimary"])
    ]
)
data class BusinessProfileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessName: String,
    val tagline: String = "",
    val category: String, // from BusinessCategory enum name
    val currencySymbol: String = "$",
    val currencyCode: String = "USD",
    val defaultTaxRate: Double = 5.0,
    val taxNumber: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val activeModulesCsv: String = "POS,INVENTORY,CUSTOMERS,REPORTS,LEDGER,AUDIT",
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val isPrimary: Boolean = false
)
