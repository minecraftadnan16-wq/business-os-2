package com.example.ultimatebusinessos.domain.model

enum class BusinessCategory(
    val title: String,
    val description: String,
    val defaultTaxRate: Double,
    val specializedTag: String,
    val recommendedModules: List<String>
) {
    RETAIL(
        title = "Retail Store",
        description = "General retail, consumer goods, counter billing and inventory",
        defaultTaxRate = 5.0,
        specializedTag = "Barcode Scanner & Counter POS",
        recommendedModules = listOf("POS", "INVENTORY", "CUSTOMERS", "REPORTS", "DISCOUNTS")
    ),
    WHOLESALE(
        title = "Wholesale & Bulk",
        description = "Bulk quantity tier pricing, ledger accounts, credit terms, packing lists",
        defaultTaxRate = 0.0,
        specializedTag = "Tier Pricing & Credit Limits",
        recommendedModules = listOf("TIER_PRICING", "INVOICING", "CREDIT_LEDGER", "SUPPLIERS", "BULK_ORDERS")
    ),
    GROCERY(
        title = "Grocery & Supermarket",
        description = "Fast item lookup, weighed produce, perishable expiry, barcode support",
        defaultTaxRate = 3.0,
        specializedTag = "Perishable Expiry & Fast Barcode",
        recommendedModules = listOf("POS", "EXPIRY_TRACKER", "WEIGHT_SCALE", "BARCODE", "REORDER_ALERTS")
    ),
    CLOTHING_FASHION(
        title = "Clothing & Fashion",
        description = "Apparel with multi-variant matrices (Size, Color, Fit, Fabric)",
        defaultTaxRate = 6.0,
        specializedTag = "Size / Color Variant Matrix",
        recommendedModules = listOf("VARIANTS", "SEASONAL_CATALOG", "POS", "RETURNS", "BARCODE")
    ),
    ELECTRONICS_MOBILE(
        title = "Electronics & Mobile Shop",
        description = "Smartphones, gadgets with IMEI / Serial warranty tracking & repairs",
        defaultTaxRate = 8.0,
        specializedTag = "IMEI & Warranty Serial Tracker",
        recommendedModules = listOf("IMEI_SERIAL", "WARRANTY_TRACKER", "REPAIR_SERVICE", "INVOICING")
    ),
    COMPUTER_SHOP(
        title = "Computer & IT Equipment",
        description = "Custom PC builds, hardware component serials, warranty, IT services",
        defaultTaxRate = 8.0,
        specializedTag = "Serial Numbers & Service Tickets",
        recommendedModules = listOf("IMEI_SERIAL", "SERVICE_TICKETS", "QUOTATIONS", "INVENTORY")
    ),
    PHARMACY(
        title = "Pharmacy & Chemist",
        description = "Batch numbers, medicine expiry alerts, prescription records, doctor info",
        defaultTaxRate = 0.0,
        specializedTag = "Batch & Expiration / Rx Audit",
        recommendedModules = listOf("BATCH_TRACKING", "EXPIRY_AUDIT", "PRESCRIPTION_LOG", "SUPPLIER_REORDER")
    ),
    RESTAURANT_CAFE(
        title = "Restaurant, Cafe & Bakery",
        description = "Table management, Kitchen Display (KDS), menu recipes, dining tabs",
        defaultTaxRate = 8.5,
        specializedTag = "Table Orders & Kitchen Stations",
        recommendedModules = listOf("TABLE_MANAGEMENT", "KITCHEN_ORDERS", "RECIPE_BOM", "QUICK_TABS")
    ),
    HARDWARE_FURNITURE(
        title = "Hardware & Furniture",
        description = "Bulky items, dimensional specs, delivery scheduling, installation",
        defaultTaxRate = 7.0,
        specializedTag = "Dimensions, Units & Delivery Notes",
        recommendedModules = listOf("MULTI_UNIT", "DELIVERY_ORDERS", "INSTALLMENT_PAYMENTS", "SUPPLIERS")
    ),
    BOOKSTORE(
        title = "Bookstore & Stationery",
        description = "ISBN cataloging, author, publisher, academic edition management",
        defaultTaxRate = 2.0,
        specializedTag = "ISBN Catalog & Publisher Index",
        recommendedModules = listOf("ISBN_LOOKUP", "BARCODE", "INVENTORY", "LOYALTY_PROGRAM")
    ),
    ECOMMERCE(
        title = "E-Commerce Business",
        description = "Online orders, shipping carriers, tracking numbers, omnichannel stock",
        defaultTaxRate = 6.5,
        specializedTag = "Shipping, Tracking & Digital Orders",
        recommendedModules = listOf("ONLINE_ORDERS", "SHIPPING_TRACK", "DIGITAL_CATALOG", "PAYMENT_GATEWAYS")
    ),
    MANUFACTURING(
        title = "Manufacturing & Production",
        description = "Raw materials, Bill of Materials (BOM), production batches, scrap tracking",
        defaultTaxRate = 5.0,
        specializedTag = "Bill of Materials (BOM) & Work Orders",
        recommendedModules = listOf("BOM_RECIPES", "RAW_MATERIALS", "PRODUCTION_RUNS", "COSTING")
    ),
    IMPORT_EXPORT(
        title = "Import / Export & Customs",
        description = "Multi-currency, tariffs, container tracking, landed cost valuation",
        defaultTaxRate = 0.0,
        specializedTag = "Multi-Currency & Landed Cost",
        recommendedModules = listOf("MULTI_CURRENCY", "TARIFF_CUSTOMS", "CONTAINER_TRACK", "SUPPLIERS")
    ),
    AGRICULTURE_CONSTRUCTION(
        title = "Agriculture & Construction",
        description = "Job site projects, bulk materials, equipment rentals, harvest batches",
        defaultTaxRate = 4.0,
        specializedTag = "Job-Costing & Material Dispatch",
        recommendedModules = listOf("JOB_COSTING", "EQUIPMENT_LOG", "DISPATCH_NOTES", "CONTRACTORS")
    ),
    AUTOMOBILE(
        title = "Automobile & Spare Parts",
        description = "VIN tracking, vehicle makes/models, spare parts compatibility, garage jobs",
        defaultTaxRate = 7.5,
        specializedTag = "VIN / License & Spare Parts Index",
        recommendedModules = listOf("VEHICLE_VIN", "GARAGE_JOB_CARDS", "PARTS_CATALOG", "SERVICES")
    ),
    JEWELRY(
        title = "Jewelry & Precious Metals",
        description = "Karat purity (18K/22K/24K), weight in grams, making charges, metal rates",
        defaultTaxRate = 3.0,
        specializedTag = "Karat Purity & Gram Weight Rates",
        recommendedModules = listOf("KARAT_PURITY", "PRECIOUS_METAL_RATE", "MAKING_CHARGES", "HALLMARK")
    ),
    DISTRIBUTION_SERVICE(
        title = "Distribution & Professional Services",
        description = "Route distribution, delivery drivers, client retainers, hourly time billing",
        defaultTaxRate = 5.0,
        specializedTag = "Route Distribution & Service Invoicing",
        recommendedModules = listOf("ROUTE_DISPATCH", "SERVICE_INVOICING", "CLIENT_RETAINERS", "LEDGER")
    ),
    CUSTOM(
        title = "Custom Business Category",
        description = "Fully bespoke configuration with user-selected modules and flexible fields",
        defaultTaxRate = 5.0,
        specializedTag = "Modular Custom Configuration",
        recommendedModules = listOf("POS", "INVENTORY", "CUSTOMERS", "REPORTS", "LEDGER")
    )
}
