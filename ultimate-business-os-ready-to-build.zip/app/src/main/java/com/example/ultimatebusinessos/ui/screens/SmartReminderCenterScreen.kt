package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SmartReminderItem(
    val title: String,
    val description: String,
    val severity: ReminderSeverity,
    val icon: ImageVector,
    val targetScreen: AppScreen,
    val actionText: String
)

enum class ReminderSeverity { HIGH, MEDIUM, LOW }

@Composable
fun SmartReminderCenterScreen(
    business: BusinessProfileEntity?,
    contacts: List<CustomerSupplierEntity>,
    products: List<ProductEntity>,
    ledgerEntries: List<FinancialLedgerEntity>,
    onNavigate: (AppScreen) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = business?.currencySymbol ?: "$"
    val now = System.currentTimeMillis()

    // Build intelligent, real computed reminders
    val reminders = remember(contacts, products, ledgerEntries) {
        val list = mutableListOf<SmartReminderItem>()

        // 1. Customer Overdue Receivables
        val debtors = contacts.filter { it.type != "SUPPLIER" && it.currentBalance > 0 }
        if (debtors.isNotEmpty()) {
            val totalDue = debtors.sumOf { it.currentBalance }
            list.add(
                SmartReminderItem(
                    title = "Customer Due Recoveries (${debtors.size} Accounts)",
                    description = "$currency${"%.2f".format(totalDue)} outstanding from customers. Send payment reminders.",
                    severity = ReminderSeverity.HIGH,
                    icon = Icons.Default.AccountBalanceWallet,
                    targetScreen = AppScreen.CUSTOMERS,
                    actionText = "Collect Dues"
                )
            )
        }

        // 2. Vendor Payables
        val creditors = contacts.filter { it.type != "CUSTOMER" && it.currentBalance < 0 }
        if (creditors.isNotEmpty()) {
            val totalPayable = creditors.sumOf { -it.currentBalance }
            list.add(
                SmartReminderItem(
                    title = "Supplier Bills Payable (${creditors.size} Vendors)",
                    description = "$currency${"%.2f".format(totalPayable)} owed to suppliers. Review credit terms and disburse payments.",
                    severity = ReminderSeverity.MEDIUM,
                    icon = Icons.Default.Store,
                    targetScreen = AppScreen.SUPPLIERS,
                    actionText = "Review Bills"
                )
            )
        }

        // 3. Low Stock Triggers
        val lowStock = products.filter { it.currentStock <= it.reorderAlertLevel }
        if (lowStock.isNotEmpty()) {
            list.add(
                SmartReminderItem(
                    title = "Low Stock Reorder Trigger (${lowStock.size} Items)",
                    description = "${lowStock.take(3).joinToString { it.name }} have reached reorder minimums.",
                    severity = ReminderSeverity.HIGH,
                    icon = Icons.Default.Inventory2,
                    targetScreen = AppScreen.PURCHASES,
                    actionText = "Replenish Stock"
                )
            )
        }

        // 4. Perishable Expiry Warnings
        val thirtyDaysEpoch = now + (30L * 24 * 3600 * 1000)
        val expiringProducts = products.filter { it.expiryDateEpoch != null && it.expiryDateEpoch <= thirtyDaysEpoch }
        if (expiringProducts.isNotEmpty()) {
            list.add(
                SmartReminderItem(
                    title = "Expiring Batches Warning (${expiringProducts.size} Items)",
                    description = "${expiringProducts.first().name} expiring soon. Consider promotional clearance or supplier return.",
                    severity = ReminderSeverity.HIGH,
                    icon = Icons.Default.EventBusy,
                    targetScreen = AppScreen.INVENTORY,
                    actionText = "Audit Expiries"
                )
            )
        }

        // 5. Unreconciled Bank Records
        val unreconciled = ledgerEntries.filter {
            (it.accountDebit == "Primary Bank Account" || it.accountCredit == "Primary Bank Account") && !it.isReconciled
        }
        if (unreconciled.isNotEmpty()) {
            list.add(
                SmartReminderItem(
                    title = "Bank Reconciliation Pending",
                    description = "${unreconciled.size} bank transactions awaiting verification against statement.",
                    severity = ReminderSeverity.LOW,
                    icon = Icons.Default.NotificationsActive,
                    targetScreen = AppScreen.CASH_BANK,
                    actionText = "Reconcile"
                )
            )
        }

        list
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("smart_reminder_screen")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Smart Reminder Center",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Automated proactive alerts for credit, stock & operations",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        HorizontalDivider()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Operational Priority Queue", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text("${reminders.size} active items require your attention today", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            if (reminders.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(52.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("All clear! No overdue items or stock warnings.", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                items(reminders) { item ->
                    ReminderCard(item = item, onAction = { onNavigate(item.targetScreen) })
                }
            }
        }
    }
}

@Composable
fun ReminderCard(
    item: SmartReminderItem,
    onAction: () -> Unit
) {
    val borderColor = when (item.severity) {
        ReminderSeverity.HIGH -> Color(0xFFEF476F)
        ReminderSeverity.MEDIUM -> Color(0xFFFFB703)
        ReminderSeverity.LOW -> Color(0xFF38BDF8)
    }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(borderColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = item.icon, contentDescription = null, tint = borderColor, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = borderColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = item.severity.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = borderColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(item.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onAction,
                modifier = Modifier.align(Alignment.End),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(item.actionText, fontSize = 12.sp)
            }
        }
    }
}
