package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen

@Composable
fun SimpleModeDashboard(
    business: BusinessProfileEntity?,
    revenue: Double,
    expenses: Double,
    cashBalance: Double,
    receivables: Double,
    payables: Double,
    lowStockCount: Int,
    contacts: List<CustomerSupplierEntity>,
    onNavigate: (AppScreen) -> Unit,
    onReceiveMoney: (CustomerSupplierEntity, Double, String, String) -> Unit,
    onPayMoney: (CustomerSupplierEntity, Double, String, String) -> Unit,
    onAddExpense: (String, Double, String) -> Unit,
    onSwitchMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = business?.currencySymbol ?: "$"
    var showReceiveDialog by remember { mutableStateOf(false) }
    var showPayDialog by remember { mutableStateOf(false) }
    var showExpenseDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("simple_dashboard_screen")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Glass Banner & Mode Indicator
        item {
            com.example.ultimatebusinessos.ui.theme.GlassCard(
                glowColor = Color(0xFF00E5FF),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "LIQUID GLASS • SHOPKEEPER",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        OutlinedButton(
                            onClick = onSwitchMode,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Professional", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = business?.businessName ?: "My Shop",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Translucent liquid interface with large direct actions for shopkeepers.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Quick Daily Cash Snapshot (Glass Card with Dual Ambient Glow)
        item {
            com.example.ultimatebusinessos.ui.theme.GlassCard(
                glowColor = Color(0xFF10B981),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Cash In Drawer", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$currency${"%.2f".format(cashBalance)}",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF00E5FF)
                        )
                        Text("Instant physical float", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Today's Profit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val profit = revenue - expenses
                        Text(
                            text = "$currency${"%.2f".format(profit)}",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (profit >= 0) Color(0xFF10B981) else Color(0xFFF43F5E)
                        )
                        Text("After all expenses", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    }
                }
            }
        }

        // Interactive Liquid Wave Chart
        item {
            com.example.ultimatebusinessos.ui.components.LiquidFinancialWaveChart(
                revenuePoints = listOf(revenue * 0.35, revenue * 0.55, revenue * 0.8, revenue),
                profitPoints = listOf((revenue - expenses) * 0.4, (revenue - expenses) * 0.65, (revenue - expenses)),
                labels = listOf("Start", "Morning", "Afternoon", "Current"),
                currencySymbol = currency
            )
        }

        // 8 Large Action Buttons for Shopkeepers
        item {
            Text("Quick Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Row 1: Quick Sale & Quick Purchase
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LargeActionButton(
                        title = "Quick Sale",
                        subtitle = "Sell items & bill",
                        icon = Icons.Default.PointOfSale,
                        color = Color(0xFF00E5FF),
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_sale",
                        onClick = { onNavigate(AppScreen.SALES) }
                    )
                    LargeActionButton(
                        title = "Quick Purchase",
                        subtitle = "Add incoming stock",
                        icon = Icons.Default.ShoppingCart,
                        color = Color(0xFF38BDF8),
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_purchase",
                        onClick = { onNavigate(AppScreen.PURCHASES) }
                    )
                }

                // Row 2: Receive Money & Pay Money
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LargeActionButton(
                        title = "Receive Money",
                        subtitle = "Collect from customer",
                        icon = Icons.Default.CallReceived,
                        color = Color(0xFF059669),
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_receive",
                        onClick = { showReceiveDialog = true }
                    )
                    LargeActionButton(
                        title = "Pay Money",
                        subtitle = "Pay vendor / supplier",
                        icon = Icons.Default.CallMade,
                        color = Color(0xFFD97706),
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_pay",
                        onClick = { showPayDialog = true }
                    )
                }

                // Row 3: Add Expense & Check Due
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LargeActionButton(
                        title = "Add Expense",
                        subtitle = "Rent, tea, utilities",
                        icon = Icons.Default.Receipt,
                        color = Color(0xFFE11D48),
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_expense",
                        onClick = { showExpenseDialog = true }
                    )
                    LargeActionButton(
                        title = "Check Due",
                        subtitle = "Who owes you money",
                        icon = Icons.Default.AccountBalanceWallet,
                        color = Color(0xFF7C3AED),
                        badge = if (receivables > 0) "$currency${"%.0f".format(receivables)}" else null,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_check_due",
                        onClick = { onNavigate(AppScreen.CUSTOMERS) }
                    )
                }

                // Row 4: Check Stock & View Reports
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LargeActionButton(
                        title = "Check Stock",
                        subtitle = "Item counts & alerts",
                        icon = Icons.Default.Inventory2,
                        color = Color(0xFF0891B2),
                        badge = if (lowStockCount > 0) "$lowStockCount low" else null,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_check_stock",
                        onClick = { onNavigate(AppScreen.INVENTORY) }
                    )
                    LargeActionButton(
                        title = "View Reports",
                        subtitle = "Sales & Profit today",
                        icon = Icons.Default.Assessment,
                        color = Color(0xFF4F46E5),
                        modifier = Modifier.weight(1f),
                        testTag = "btn_simple_reports",
                        onClick = { onNavigate(AppScreen.REPORTS_ANALYTICS) }
                    )
                }
            }
        }

        // Summary Badges
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Today's Business Health", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Total Sales: $currency${"%.2f".format(revenue)}", style = MaterialTheme.typography.bodyMedium)
                    Text("• Money Customers Owe You: $currency${"%.2f".format(receivables)}", style = MaterialTheme.typography.bodyMedium)
                    Text("• Money You Owe Suppliers: $currency${"%.2f".format(payables)}", style = MaterialTheme.typography.bodyMedium)
                    if (lowStockCount > 0) {
                        Text("• Alert: $lowStockCount items are running low on stock", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Receive Money Dialog
    if (showReceiveDialog) {
        val customers = contacts.filter { it.type != "SUPPLIER" }
        SimpleReceiveMoneyDialog(
            currency = currency,
            customers = customers,
            onDismiss = { showReceiveDialog = false },
            onConfirm = { cust, amt, dest, notes ->
                onReceiveMoney(cust, amt, dest, notes)
                showReceiveDialog = false
            }
        )
    }

    // Pay Money Dialog
    if (showPayDialog) {
        val suppliers = contacts.filter { it.type != "CUSTOMER" }
        SimplePayMoneyDialog(
            currency = currency,
            suppliers = suppliers,
            onDismiss = { showPayDialog = false },
            onConfirm = { supp, amt, src, notes ->
                onPayMoney(supp, amt, src, notes)
                showPayDialog = false
            }
        )
    }

    // Add Expense Dialog
    if (showExpenseDialog) {
        RecordExpenseDialog(
            currency = currency,
            onDismiss = { showExpenseDialog = false },
            onConfirm = { title, amt, cat ->
                onAddExpense(title, amt, cat)
                showExpenseDialog = false
            }
        )
    }
}

@Composable
fun LargeActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    badge: String? = null,
    testTag: String,
    onClick: () -> Unit
) {
    com.example.ultimatebusinessos.ui.theme.GlassCard(
        modifier = modifier
            .height(118.dp)
            .testTag(testTag),
        glowColor = color,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
                }

                if (badge != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = color.copy(alpha = 0.18f)
                    ) {
                        Text(
                            text = badge,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = color,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Column {
                Text(text = title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleReceiveMoneyDialog(
    currency: String,
    customers: List<CustomerSupplierEntity>,
    onDismiss: () -> Unit,
    onConfirm: (CustomerSupplierEntity, Double, String, String) -> Unit
) {
    var selectedCustomer by remember { mutableStateOf(customers.firstOrNull()) }
    var expandedMenu by remember { mutableStateOf(false) }
    var amountInput by remember { mutableStateOf("") }
    var destinationAccount by remember { mutableStateOf("Cash On Hand") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receive Money (Customer Debt)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (customers.isEmpty()) {
                    Text("No customers found. Add a customer first.", color = Color(0xFFDC2626))
                } else {
                    ExposedDropdownMenuBox(
                        expanded = expandedMenu,
                        onExpandedChange = { expandedMenu = !expandedMenu }
                    ) {
                        OutlinedTextField(
                            value = selectedCustomer?.let { "${it.name} (Due: $currency${"%.2f".format(it.currentBalance)})" } ?: "Select Customer",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Customer") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMenu) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedMenu,
                            onDismissRequest = { expandedMenu = false }
                        ) {
                            customers.forEach { cust ->
                                DropdownMenuItem(
                                    text = { Text("${cust.name} (Due: $currency${"%.2f".format(cust.currentBalance)})") },
                                    onClick = {
                                        selectedCustomer = cust
                                        amountInput = if (cust.currentBalance > 0) cust.currentBalance.toString() else ""
                                        expandedMenu = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount Received ($currency) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { destinationAccount = "Cash On Hand" },
                            colors = if (destinationAccount == "Cash On Hand") ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cash Drawer")
                        }
                        OutlinedButton(
                            onClick = { destinationAccount = "Primary Bank Account" },
                            colors = if (destinationAccount == "Primary Bank Account") ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Bank Account")
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Receipt Reference") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cust = selectedCustomer
                    val amt = amountInput.toDoubleOrNull()
                    if (cust != null && amt != null && amt > 0.0) {
                        onConfirm(cust, amt, destinationAccount, notes)
                    }
                },
                enabled = selectedCustomer != null
            ) {
                Text("Confirm Collection")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimplePayMoneyDialog(
    currency: String,
    suppliers: List<CustomerSupplierEntity>,
    onDismiss: () -> Unit,
    onConfirm: (CustomerSupplierEntity, Double, String, String) -> Unit
) {
    var selectedSupplier by remember { mutableStateOf(suppliers.firstOrNull()) }
    var expandedMenu by remember { mutableStateOf(false) }
    var amountInput by remember { mutableStateOf("") }
    var sourceAccount by remember { mutableStateOf("Cash On Hand") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pay Money (Supplier Bill)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (suppliers.isEmpty()) {
                    Text("No suppliers found. Add a supplier first.", color = Color(0xFFDC2626))
                } else {
                    ExposedDropdownMenuBox(
                        expanded = expandedMenu,
                        onExpandedChange = { expandedMenu = !expandedMenu }
                    ) {
                        OutlinedTextField(
                            value = selectedSupplier?.let { "${it.name} (Payable: $currency${"%.2f".format(-it.currentBalance)})" } ?: "Select Supplier",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Supplier") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMenu) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedMenu,
                            onDismissRequest = { expandedMenu = false }
                        ) {
                            suppliers.forEach { supp ->
                                DropdownMenuItem(
                                    text = { Text("${supp.name} (Payable: $currency${"%.2f".format(-supp.currentBalance)})") },
                                    onClick = {
                                        selectedSupplier = supp
                                        amountInput = if (supp.currentBalance < 0) (-supp.currentBalance).toString() else ""
                                        expandedMenu = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount Paid ($currency) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { sourceAccount = "Cash On Hand" },
                            colors = if (sourceAccount == "Cash On Hand") ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("From Cash")
                        }
                        OutlinedButton(
                            onClick = { sourceAccount = "Primary Bank Account" },
                            colors = if (sourceAccount == "Primary Bank Account") ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("From Bank")
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Cheque Ref") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val supp = selectedSupplier
                    val amt = amountInput.toDoubleOrNull()
                    if (supp != null && amt != null && amt > 0.0) {
                        onConfirm(supp, amt, sourceAccount, notes)
                    }
                },
                enabled = selectedSupplier != null
            ) {
                Text("Confirm Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
