package com.example.ultimatebusinessos.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.ultimatebusinessos.data.local.dao.AuditLogDao
import com.example.ultimatebusinessos.data.local.dao.BusinessDao
import com.example.ultimatebusinessos.data.local.dao.CustomerSupplierDao
import com.example.ultimatebusinessos.data.local.dao.EmployeeDao
import com.example.ultimatebusinessos.data.local.dao.LedgerDao
import com.example.ultimatebusinessos.data.local.dao.OrderDao
import com.example.ultimatebusinessos.data.local.dao.ProductDao
import com.example.ultimatebusinessos.data.local.entity.AuditLogEntity
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.EmployeeEntity
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import com.example.ultimatebusinessos.data.local.entity.OrderInvoiceEntity
import com.example.ultimatebusinessos.data.local.entity.OrderItemEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity

@Database(
    entities = [
        BusinessProfileEntity::class,
        ProductEntity::class,
        CustomerSupplierEntity::class,
        OrderInvoiceEntity::class,
        OrderItemEntity::class,
        FinancialLedgerEntity::class,
        AuditLogEntity::class,
        EmployeeEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun businessDao(): BusinessDao
    abstract fun productDao(): ProductDao
    abstract fun customerSupplierDao(): CustomerSupplierDao
    abstract fun orderDao(): OrderDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun employeeDao(): EmployeeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ultimate_business_os.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
