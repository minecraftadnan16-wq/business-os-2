package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "system_audit_logs",
    foreignKeys = [
        ForeignKey(
            entity = BusinessProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["businessId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["businessId", "timestampEpoch"]),
        Index(value = ["action"])
    ]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val timestampEpoch: Long = System.currentTimeMillis(),
    val action: String, // "CREATE_BUSINESS", "CREATE_PRODUCT", "SALE_COMPLETED", "STOCK_ADJUSTED", "CONTACT_ADDED", "EXPENSE_LOGGED"
    val entityType: String,
    val entityId: String,
    val details: String,
    val actor: String = "Admin / Owner",
    val integrityHash: String = ""
)
