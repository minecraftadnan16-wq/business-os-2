package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.CustomerSupplierEntity
import com.example.ultimatebusinessos.data.local.entity.OrderInvoiceEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.data.repository.BusinessRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PurchasesScreen(
    business: BusinessProfileEntity?,
    purchases: List<OrderInvoiceEntity>,
    suppliers: List<CustomerSupplierEntity>,
    products: List<ProductEntity>,
    onRecordPurchase: (supplier: CustomerSupplierEntity?, items: List<BusinessRepository.CartItem>, paymentMethod: String, amountPaid: Double, notes: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = business?.currencySymbol ?: "$"
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier.testTag("new_purchase_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Purchase")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .testTag("purchases_screen")
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Purchases & Vendor Bills",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Stock replenishment and vendor credit management",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider()

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    val totalPurchasesVal = purchases.sumOf { it.grandTotal }
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Total Purchases Recorded", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "$currency${"%.2f".format(totalPurchasesVal)}",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "${purchases.size} Vendor Bills",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                    }
                }

                if (purchases.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No purchase orders recorded yet", style = MaterialTheme.typography.bodyMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(onClick = { showCreateDialog = true }) {
                                    Text("Record Purchase Order")
                                }
                            }
                        }
                    }
                } else {
                    items(purchases) { purchase ->
                        PurchaseRowCard(purchase = purchase, currency = currency)
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(64.dp))
                }
            }
        }
    }

    if (showCreateDialog) {
        CreatePurchaseDialog(
            currency = currency,
            suppliers = suppliers.filter { it.type != "CUSTOMER" },
            products = products,
            onDismiss = { showCreateDialog = false },
            onConfirm = { supp, items, method, paid, notes ->
                onRecordPurchase(supp, items, method, paid, notes)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun PurchaseRowCard(purchase: OrderInvoiceEntity, currency: String) {
    val dateStr = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(purchase.orderDateEpoch))
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(purchase.invoiceNumber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (purchase.paymentStatus == "PAID") Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                    ) {
                        Text(
                            text = purchase.paymentStatus,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (purchase.paymentStatus == "PAID") Color(0xFF065F46) else Color(0xFF991B1B),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("Supplier: ${purchase.customerSupplierName} • $dateStr", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (purchase.balanceDue > 0.0) {
                    Text("Due Balance: $currency${"%.2f".format(purchase.balanceDue)}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$currency${"%.2f".format(purchase.grandTotal)}",
                    fontWeight = FontWeight.ExtraBold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(purchase.paymentMethod, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePurchaseDialog(
    currency: String,
    suppliers: List<CustomerSupplierEntity>,
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onConfirm: (CustomerSupplierEntity?, List<BusinessRepository.CartItem>, String, Double, String) -> Unit
) {
    var selectedSupplier by remember { mutableStateOf(suppliers.firstOrNull()) }
    var expandedSupplierMenu by remember { mutableStateOf(false) }

    val purchaseItems = remember { mutableStateListOf<BusinessRepository.CartItem>() }
    var selectedProductToAdd by remember { mutableStateOf(products.firstOrNull()) }
    var addQtyInput by remember { mutableStateOf("10") }
    var addCostInput by remember { mutableStateOf(products.firstOrNull()?.costPrice?.toString() ?: "0") }

    var paymentMethod by remember { mutableStateOf("CASH") }
    var paidInput by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val totalBill = purchaseItems.sumOf { it.quantity * it.unitPrice }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Purchase Order / Bill") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Supplier Selector
                ExposedDropdownMenuBox(
                    expanded = expandedSupplierMenu,
                    onExpandedChange = { expandedSupplierMenu = !expandedSupplierMenu }
                ) {
                    OutlinedTextField(
                        value = selectedSupplier?.name ?: "Direct Vendor / Cash",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Vendor / Supplier") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedSupplierMenu) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedSupplierMenu,
                        onDismissRequest = { expandedSupplierMenu = false }
                    ) {
                        suppliers.forEach { supp ->
                            DropdownMenuItem(
                                text = { Text(supp.name) },
                                onClick = {
                                    selectedSupplier = supp
                                    expandedSupplierMenu = false
                                }
                            )
                        }
                    }
                }

                HorizontalDivider()

                // Add Items into Purchase Bill
                Text("Select Product to Replenish:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                if (products.isNotEmpty()) {
                    var expandedProdMenu by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = expandedProdMenu,
                        onExpandedChange = { expandedProdMenu = !expandedProdMenu }
                    ) {
                        OutlinedTextField(
                            value = selectedProductToAdd?.name ?: "Select Product",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Item") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProdMenu) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedProdMenu,
                            onDismissRequest = { expandedProdMenu = false }
                        ) {
                            products.forEach { prod ->
                                DropdownMenuItem(
                                    text = { Text("${prod.name} (Cost: $currency${prod.costPrice})") },
                                    onClick = {
                                        selectedProductToAdd = prod
                                        addCostInput = prod.costPrice.toString()
                                        expandedProdMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = addQtyInput,
                            onValueChange = { addQtyInput = it },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = addCostInput,
                            onValueChange = { addCostInput = it },
                            label = { Text("Cost ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                val prod = selectedProductToAdd
                                val qty = addQtyInput.toDoubleOrNull() ?: 1.0
                                val cost = addCostInput.toDoubleOrNull() ?: (prod?.costPrice ?: 0.0)
                                if (prod != null && qty > 0) {
                                    purchaseItems.add(
                                        BusinessRepository.CartItem(
                                            product = prod,
                                            quantity = qty,
                                            unitPrice = cost
                                        )
                                    )
                                }
                            }
                        ) {
                            Text("Add")
                        }
                    }
                }

                // Purchase Items List
                purchaseItems.forEachIndexed { idx, item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${item.product.name} (x${"%.0f".format(item.quantity)})", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Text("$currency${"%.2f".format(item.quantity * item.unitPrice)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        IconButton(onClick = { purchaseItems.removeAt(idx) }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", modifier = Modifier.size(16.dp))
                        }
                    }
                }

                HorizontalDivider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Bill:", fontWeight = FontWeight.Bold)
                    Text("$currency${"%.2f".format(totalBill)}", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("CASH", "BANK", "CREDIT_LEDGER").forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = { Text(method.replace("_", " "), fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = paidInput,
                    onValueChange = { paidInput = it },
                    label = { Text("Amount Paid Now ($currency)") },
                    placeholder = { Text(totalBill.toString()) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paid = paidInput.toDoubleOrNull() ?: (if (paymentMethod == "CREDIT_LEDGER") 0.0 else totalBill)
                    if (purchaseItems.isNotEmpty()) {
                        onConfirm(selectedSupplier, purchaseItems.toList(), paymentMethod, paid, notes)
                    }
                },
                enabled = purchaseItems.isNotEmpty()
            ) {
                Text("Confirm Purchase")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
