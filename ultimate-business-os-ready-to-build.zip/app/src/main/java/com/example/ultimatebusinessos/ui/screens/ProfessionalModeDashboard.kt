package com.example.ultimatebusinessos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ultimatebusinessos.data.local.entity.BusinessProfileEntity
import com.example.ultimatebusinessos.data.local.entity.FinancialLedgerEntity
import com.example.ultimatebusinessos.data.local.entity.ProductEntity
import com.example.ultimatebusinessos.ui.viewmodel.AppScreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfessionalModeDashboard(
    business: BusinessProfileEntity?,
    revenue: Double,
    expenses: Double,
    inventoryValuation: Double,
    cashBalance: Double,
    bankBalance: Double,
    receivables: Double,
    payables: Double,
    ledgerEntries: List<FinancialLedgerEntity>,
    products: List<ProductEntity>,
    onNavigate: (AppScreen) -> Unit,
    onRecordJournalEntry: (String, String, Double, String) -> Unit,
    onToggleReconciliation: (Long, Boolean) -> Unit,
    onSwitchMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currency = business?.currencySymbol ?: "$"
    var selectedProTab by remember { mutableStateOf(0) } // 0: Financial Statements & KPIs, 1: General Ledger, 2: Trial Balance, 3: Bank Reconciliation
    var showJournalDialog by remember { mutableStateOf(false) }

    // Dynamic Account Aggregations for Trial Balance
    val accountsMap = remember(ledgerEntries) {
        val debits = mutableMapOf<String, Double>()
        val credits = mutableMapOf<String, Double>()
        for (e in ledgerEntries) {
            debits[e.accountDebit] = (debits[e.accountDebit] ?: 0.0) + e.amount
            credits[e.accountCredit] = (credits[e.accountCredit] ?: 0.0) + e.amount
        }
        val allAccounts = (debits.keys + credits.keys).distinct().sorted()
        allAccounts.map { acct ->
            Triple(acct, debits[acct] ?: 0.0, credits[acct] ?: 0.0)
        }
    }

    val totalDebitsSum = remember(accountsMap) { accountsMap.sumOf { it.second } }
    val totalCreditsSum = remember(accountsMap) { accountsMap.sumOf { it.third } }
    val variance = remember(totalDebitsSum, totalCreditsSum) { totalDebitsSum - totalCreditsSum }
    val isBalanced = Math.abs(variance) < 0.01

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("professional_dashboard_screen")
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Professional Mode Header
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0F172A)
                        ) {
                            Text(
                                text = "PROFESSIONAL ERP MODE",
                                color = Color(0xFF38BDF8),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        OutlinedButton(
                            onClick = onSwitchMode,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Simple Mode", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "${business?.businessName} • Financial Control Center",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Full double-entry general ledger, journal vouchers, trial balance & tax reconciliation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Trial Balance Integrity Indicator
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isBalanced) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isBalanced) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (isBalanced) Color(0xFF065F46) else Color(0xFF991B1B)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isBalanced) "Ledger Balanced: Debits = Credits" else "Trial Balance Out of Balance!",
                                fontWeight = FontWeight.Bold,
                                color = if (isBalanced) Color(0xFF065F46) else Color(0xFF991B1B)
                            )
                            Text(
                                text = "Total Dr: $currency${"%.2f".format(totalDebitsSum)}  |  Total Cr: $currency${"%.2f".format(totalCreditsSum)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isBalanced) Color(0xFF047857) else Color(0xFFB91C1C)
                            )
                        }
                    }

                    Button(
                        onClick = { showJournalDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("post_journal_voucher_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Post JV", fontSize = 12.sp)
                    }
                }
            }
        }

        // Tabs
        item {
            TabRow(selectedTabIndex = selectedProTab) {
                Tab(selected = selectedProTab == 0, onClick = { selectedProTab = 0 }, text = { Text("Overview") })
                Tab(selected = selectedProTab == 1, onClick = { selectedProTab = 1 }, text = { Text("General Ledger") })
                Tab(selected = selectedProTab == 2, onClick = { selectedProTab = 2 }, text = { Text("Trial Balance") })
                Tab(selected = selectedProTab == 3, onClick = { selectedProTab = 3 }, text = { Text("Reconciliation") })
            }
        }

        when (selectedProTab) {
            0 -> {
                // Overview & Balance Sheet Estimates
                item {
                    val totalAssets = cashBalance + bankBalance + receivables + inventoryValuation
                    val totalLiabilities = payables
                    val netEquity = totalAssets - totalLiabilities

                    com.example.ultimatebusinessos.ui.theme.GlassCard(
                        glowColor = Color(0xFF8B5CF6),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text("Balance Sheet Snapshot", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Assets = Liabilities + Equity (Double-Entry Standard)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(14.dp))

                            ProMetricRow(label = "Total Current Assets", value = "$currency${"%.2f".format(totalAssets)}", isBold = true)
                            ProMetricRow(label = "  • Cash On Hand", value = "$currency${"%.2f".format(cashBalance)}")
                            ProMetricRow(label = "  • Primary Bank Account", value = "$currency${"%.2f".format(bankBalance)}")
                            ProMetricRow(label = "  • Accounts Receivable", value = "$currency${"%.2f".format(receivables)}")
                            ProMetricRow(label = "  • Inventory Asset", value = "$currency${"%.2f".format(inventoryValuation)}")

                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                            ProMetricRow(label = "Total Liabilities (Accounts Payable)", value = "$currency${"%.2f".format(totalLiabilities)}", isBold = true)
                            ProMetricRow(label = "Net Business Equity", value = "$currency${"%.2f".format(netEquity)}", isBold = true, isHighlighted = true)
                        }
                    }
                }

                // Liquid Asset Allocation Donut Chart
                item {
                    com.example.ultimatebusinessos.ui.components.LiquidAssetDonutChart(
                        cashAmount = cashBalance,
                        bankAmount = bankBalance,
                        inventoryAmount = inventoryValuation,
                        receivablesAmount = receivables,
                        currencySymbol = currency
                    )
                }

                // Liquid Wave Performance Chart
                item {
                    com.example.ultimatebusinessos.ui.components.LiquidFinancialWaveChart(
                        revenuePoints = listOf(revenue * 0.25, revenue * 0.45, revenue * 0.7, revenue),
                        profitPoints = listOf((revenue - expenses) * 0.3, (revenue - expenses) * 0.55, (revenue - expenses)),
                        labels = listOf("W1", "W2", "W3", "Current"),
                        currencySymbol = currency
                    )
                }

                item {
                    Text("Enterprise Modules", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onNavigate(AppScreen.ACCOUNTING) }, modifier = Modifier.weight(1f)) {
                            Text("Full Accounting", fontSize = 11.sp)
                        }
                        OutlinedButton(onClick = { onNavigate(AppScreen.REPORTS_ANALYTICS) }, modifier = Modifier.weight(1f)) {
                            Text("Financial Statements", fontSize = 11.sp)
                        }
                        OutlinedButton(onClick = { onNavigate(AppScreen.INVENTORY) }, modifier = Modifier.weight(1f)) {
                            Text("Stock Valuation", fontSize = 11.sp)
                        }
                    }
                }
            }

            1 -> {
                // General Ledger View
                item {
                    Text("General Ledger Entries (${ledgerEntries.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }
                items(ledgerEntries) { entry ->
                    LedgerEntryCard(entry = entry, currency = currency)
                }
            }

            2 -> {
                // Trial Balance Table
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Account Name", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(2f))
                                Text("Debit ($currency)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                Text("Credit ($currency)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                            accountsMap.forEach { (acct, deb, cred) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(acct, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(2f))
                                    Text(if (deb > 0) "%.2f".format(deb) else "-", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                    Text(if (cred > 0) "%.2f".format(cred) else "-", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Totals:", fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                                Text("$currency${"%.2f".format(totalDebitsSum)}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text("$currency${"%.2f".format(totalCreditsSum)}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            3 -> {
                // Bank Reconciliation
                item {
                    val bankEntries = ledgerEntries.filter { it.accountDebit == "Primary Bank Account" || it.accountCredit == "Primary Bank Account" }
                    val clearedCount = bankEntries.count { it.isReconciled }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Bank Statement Reconciliation", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("Book Balance: $currency${"%.2f".format(bankBalance)} • Cleared items: $clearedCount / ${bankEntries.size}", style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Check transactions that match your bank statement to reconcile your books.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }

                val bankItems = ledgerEntries.filter { it.accountDebit == "Primary Bank Account" || it.accountCredit == "Primary Bank Account" }
                if (bankItems.isEmpty()) {
                    item {
                        Text("No bank transactions to reconcile yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(bankItems) { entry ->
                        OutlinedCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${entry.referenceType} • ${entry.description}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Dr: ${entry.accountDebit}  |  Cr: ${entry.accountCredit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("Amount: $currency${"%.2f".format(entry.amount)}", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (entry.isReconciled) "Cleared" else "Pending",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (entry.isReconciled) Color(0xFF059669) else Color(0xFFD97706)
                                    )
                                    Checkbox(
                                        checked = entry.isReconciled,
                                        onCheckedChange = { onToggleReconciliation(entry.id, entry.isReconciled) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Manual Journal Voucher Dialog
    if (showJournalDialog) {
        PostJournalVoucherDialog(
            currency = currency,
            onDismiss = { showJournalDialog = false },
            onConfirm = { dr, cr, amt, desc ->
                onRecordJournalEntry(dr, cr, amt, desc)
                showJournalDialog = false
            }
        )
    }
}

@Composable
fun ProMetricRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    isHighlighted: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isHighlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun PostJournalVoucherDialog(
    currency: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Double, String) -> Unit
) {
    var debitAccount by remember { mutableStateOf("Cash On Hand") }
    var creditAccount by remember { mutableStateOf("Sales Revenue") }
    var amountInput by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    val accounts = listOf(
        "Cash On Hand",
        "Primary Bank Account",
        "Accounts Receivable",
        "Inventory Asset",
        "Accounts Payable",
        "Sales Revenue",
        "Owner's Equity",
        "Cost of Goods Sold",
        "Operating Expenses"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Post Journal Voucher (JV)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Double-Entry Rule: Debit account increases assets/expenses; Credit account increases revenue/liabilities/equity.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = debitAccount,
                    onValueChange = { debitAccount = it },
                    label = { Text("Debit Account (Dr) *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = creditAccount,
                    onValueChange = { creditAccount = it },
                    label = { Text("Credit Account (Cr) *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Balanced Voucher Amount ($currency) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Journal Memo / Purpose *") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull()
                    if (amt != null && amt > 0.0 && debitAccount.isNotBlank() && creditAccount.isNotBlank()) {
                        onConfirm(debitAccount, creditAccount, amt, description)
                    }
                }
            ) {
                Text("Post Voucher")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
