package com.example.ultimatebusinessos.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "financial_ledger",
    foreignKeys = [
        ForeignKey(
            entity = BusinessProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["businessId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["businessId"]),
        Index(value = ["businessId", "transactionDateEpoch"]),
        Index(value = ["referenceType", "referenceId"])
    ]
)
data class FinancialLedgerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val businessId: Long,
    val transactionDateEpoch: Long = System.currentTimeMillis(),
    val referenceType: String, // "INVOICE_SALE", "PURCHASE_BILL", "PAYMENT_RECEIVED", "EXPENSE", "CAPITAL_INJECTION"
    val referenceId: String,
    val accountDebit: String, // e.g. "Cash On Hand", "Accounts Receivable", "Bank Account", "COGS"
    val accountCredit: String, // e.g. "Sales Revenue", "Accounts Payable", "Inventory Asset", "Owner Capital"
    val amount: Double,
    val description: String,
    val createdByUser: String = "System",
    val isReconciled: Boolean = false
)
